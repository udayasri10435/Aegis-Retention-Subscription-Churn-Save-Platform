import { 
  RetentionMetrics, 
  Subscriber, 
  ChurnSignal, 
  SaveOffer, 
  WinBackCampaign, 
  CohortRow 
} from '../types/retention';

export const DTC_METRICS: RetentionMetrics = {
  totalSubscribers: 14820,
  mrr: 412400,
  grossChurnRate: 4.8,
  netChurnRate: 2.1,
  saveOfferAcceptanceRate: 38.4,
  savedRevenueThisMonth: 48600,
  winBackReactivationRate: 14.2,
  reclaimedRevenueThisMonth: 18200,
  riskDistribution: {
    critical: 412,
    high: 890,
    moderate: 2140,
    healthy: 11378
  }
};

export const SAAS_METRICS: RetentionMetrics = {
  totalSubscribers: 1420,
  mrr: 570000, // $6.84M ARR
  grossChurnRate: 1.6,
  netChurnRate: -1.8, // Net negative churn due to expansion
  saveOfferAcceptanceRate: 33.5,
  savedRevenueThisMonth: 34800,
  winBackReactivationRate: 11.8,
  reclaimedRevenueThisMonth: 29400,
  riskDistribution: {
    critical: 38,
    high: 94,
    moderate: 246,
    healthy: 1042
  }
};

export const DTC_SIGNALS: ChurnSignal[] = [
  {
    id: 'dtc_skip_streak',
    name: 'Consecutive Shipment Skips (>=2)',
    weight: 34,
    description: 'Subscriber has paused or skipped delivery twice in succession without rescheduling',
    category: 'behavior',
    changePercent: +18
  },
  {
    id: 'dtc_shipping_delay',
    name: 'Carrier Delay or Fulfillment Friction',
    weight: 22,
    description: 'Package delayed in transit > 4 days past estimated delivery window',
    category: 'product',
    changePercent: -5
  },
  {
    id: 'dtc_payment_soft_decline',
    name: 'Credit Card Soft Decline / Retry #2',
    weight: 19,
    description: 'Recurring card recharge hit insufficient funds or do-not-honor code',
    category: 'billing',
    changePercent: +8
  },
  {
    id: 'dtc_portal_inactivity',
    name: 'Customer Portal Inactivity > 45 Days',
    weight: 15,
    description: 'Zero preference edits, scent/flavor ratings, or bundle updates',
    category: 'behavior',
    changePercent: +12
  },
  {
    id: 'dtc_support_ticket',
    name: 'Damaged Item / Flavor Dissatisfaction Ticket',
    weight: 10,
    description: 'Submitted low satisfaction rating or negative sentiment ticket to support',
    category: 'support',
    changePercent: -2
  }
];

export const SAAS_SIGNALS: ChurnSignal[] = [
  {
    id: 'saas_seat_utilization',
    name: 'Seat Utilization Collapsed < 35%',
    weight: 36,
    description: 'Active daily/weekly seat licenses fell by more than 40% over the last 30 days',
    category: 'behavior',
    changePercent: +14
  },
  {
    id: 'saas_admin_dormancy',
    name: 'Primary Workspace Admin Inactivity > 21d',
    weight: 26,
    description: 'Billing owner or team champion has not authenticated or visited settings',
    category: 'behavior',
    changePercent: +9
  },
  {
    id: 'saas_data_export',
    name: 'Bulk Data Export Event Triggered',
    weight: 18,
    description: 'Admin triggered full CSV/JSON database or workspace export',
    category: 'product',
    changePercent: +24
  },
  {
    id: 'saas_invoice_retry',
    name: 'ACH / Stripe Invoice Overdue > 14d',
    weight: 12,
    description: 'Automatic invoice retry failed, entering grace period dunning cycle',
    category: 'billing',
    changePercent: -4
  },
  {
    id: 'saas_unresolved_ticket',
    name: 'P1 Escalation Unresolved > 72 Hours',
    weight: 8,
    description: 'Open critical bug or integration blocker ticket lingering without resolution',
    category: 'support',
    changePercent: +3
  }
];

export const DTC_SUBSCRIBERS: Subscriber[] = [
  {
    id: 'dtc_sub_101',
    name: 'Elena Rostova',
    email: 'elena.rostova@gmail.com',
    companyOrHandle: '@elena_wellness',
    domain: 'dtc',
    planOrSku: 'Artisan Roast Reserve (2-Bag)',
    cadence: 'bi-weekly',
    value: 48,
    mrrEquivalent: 104,
    tenureMonths: 8,
    riskScore: 89,
    riskLevel: 'critical',
    primaryRiskReason: 'Skipped 3 consecutive deliveries',
    signals: [
      { name: 'Consecutive Shipment Skips (x3)', severity: 'high', detectedAt: '2 days ago' },
      { name: 'Zero Portal Login in 54 Days', severity: 'medium', detectedAt: '12 days ago' },
      { name: 'Survey response: Product stockpile accumulating', severity: 'high', detectedAt: '3 days ago' }
    ],
    nextBillingDate: 'Oct 04, 2026',
    status: 'at_risk'
  },
  {
    id: 'dtc_sub_102',
    name: 'Marcus Vance',
    email: 'marcus.v@modernstudio.co',
    companyOrHandle: 'Portland, OR',
    domain: 'dtc',
    planOrSku: 'Single Origin Espresso Trio',
    cadence: 'monthly',
    value: 54,
    mrrEquivalent: 54,
    tenureMonths: 14,
    riskScore: 78,
    riskLevel: 'high',
    primaryRiskReason: 'Card retry #2 failed & delivery delay complaint',
    signals: [
      { name: 'Payment Soft Decline (Insufficient Funds)', severity: 'high', detectedAt: 'Yesterday' },
      { name: 'Delivery Delay Ticket filed (FedEx 5-day hold)', severity: 'medium', detectedAt: '8 days ago' }
    ],
    nextBillingDate: 'Oct 02, 2026',
    status: 'at_risk'
  },
  {
    id: 'dtc_sub_103',
    name: 'Chloe Dupont',
    email: 'chloe.dupont@artemisfood.com',
    companyOrHandle: 'Austin, TX',
    domain: 'dtc',
    planOrSku: 'Cold Brew Filter Pack (Monthly 30pk)',
    cadence: 'monthly',
    value: 39,
    mrrEquivalent: 39,
    tenureMonths: 4,
    riskScore: 84,
    riskLevel: 'critical',
    primaryRiskReason: 'Visited cancel page twice in 48h',
    signals: [
      { name: 'Cancel Page Navigation detected (did not complete)', severity: 'high', detectedAt: '18 hours ago' },
      { name: 'Skipped September Delivery', severity: 'medium', detectedAt: '14 days ago' }
    ],
    nextBillingDate: 'Oct 06, 2026',
    status: 'at_risk'
  },
  {
    id: 'dtc_sub_104',
    name: 'Julian Sterling',
    email: 'j.sterling@northwind.cc',
    companyOrHandle: 'Seattle, WA',
    domain: 'dtc',
    planOrSku: 'Roaster Select Club (Single Bag)',
    cadence: 'bi-weekly',
    value: 26,
    mrrEquivalent: 56,
    tenureMonths: 19,
    riskScore: 45,
    riskLevel: 'moderate',
    primaryRiskReason: 'Cadence mismatch / Overstocked',
    signals: [
      { name: 'Changed delivery date forward 14 days', severity: 'low', detectedAt: '5 days ago' }
    ],
    nextBillingDate: 'Oct 12, 2026',
    status: 'at_risk'
  },
  {
    id: 'dtc_sub_105',
    name: 'Siddharth Nair',
    email: 'siddharth@cloudmesh.io',
    companyOrHandle: 'San Francisco, CA',
    domain: 'dtc',
    planOrSku: 'Whole Bean Decaf Swiss Water',
    cadence: 'monthly',
    value: 32,
    mrrEquivalent: 32,
    tenureMonths: 22,
    riskScore: 22,
    riskLevel: 'healthy',
    primaryRiskReason: 'VIP Loyal Subscriber',
    signals: [],
    nextBillingDate: 'Oct 18, 2026',
    status: 'active'
  },
  {
    id: 'dtc_sub_106',
    name: 'Amara Chen',
    email: 'amara.chen@designcraft.org',
    companyOrHandle: 'Chicago, IL',
    domain: 'dtc',
    planOrSku: 'Signature Tasting Box (4 Mini Tins)',
    cadence: 'monthly',
    value: 45,
    mrrEquivalent: 45,
    tenureMonths: 3,
    riskScore: 72,
    riskLevel: 'high',
    primaryRiskReason: 'Early trial drop-off zone (Month 3)',
    signals: [
      { name: 'Unopened promotional emails x4', severity: 'medium', detectedAt: '4 days ago' },
      { name: 'Zero review submissions on shipped batches', severity: 'low', detectedAt: '10 days ago' }
    ],
    nextBillingDate: 'Oct 08, 2026',
    status: 'at_risk'
  }
];

export const SAAS_SUBSCRIBERS: Subscriber[] = [
  {
    id: 'saas_sub_201',
    name: 'Kinetics Media Ltd',
    email: 'todd.branson@kineticsmedia.com',
    companyOrHandle: 'Todd Branson (CTO)',
    domain: 'saas',
    planOrSku: 'Enterprise Cloud Grid (50 Seats)',
    cadence: 'annual',
    value: 24000,
    mrrEquivalent: 2000,
    tenureMonths: 16,
    riskScore: 92,
    riskLevel: 'critical',
    primaryRiskReason: 'Seat utilization fell from 48 to 11 seats',
    signals: [
      { name: 'Active daily seats dropped 77%', severity: 'high', detectedAt: '3 days ago' },
      { name: 'Admin bulk exported activity logs', severity: 'high', detectedAt: 'Yesterday' },
      { name: 'Zero API requests to v2 endpoint in 14d', severity: 'medium', detectedAt: '6 days ago' }
    ],
    nextBillingDate: 'Nov 15, 2026',
    status: 'at_risk'
  },
  {
    id: 'saas_sub_202',
    name: 'Acuity Health Solutions',
    email: 'sarah.mendoza@acuityhealth.org',
    companyOrHandle: 'Sarah Mendoza (VP Operations)',
    domain: 'saas',
    planOrSku: 'Growth Pro Team (25 Seats)',
    cadence: 'monthly',
    value: 1250,
    mrrEquivalent: 1250,
    tenureMonths: 9,
    riskScore: 81,
    riskLevel: 'critical',
    primaryRiskReason: 'Admin changed & critical support ticket unresolved',
    signals: [
      { name: 'Primary Champion changed email / left org', severity: 'high', detectedAt: '5 days ago' },
      { name: 'P1 Ticket #4912 open > 96 hours without resolution', severity: 'high', detectedAt: '4 days ago' }
    ],
    nextBillingDate: 'Oct 05, 2026',
    status: 'at_risk'
  },
  {
    id: 'saas_sub_203',
    name: 'OmniTrade FinTech',
    email: 'devops@omnitrade.io',
    companyOrHandle: 'Liam Sterling (Head of Infra)',
    domain: 'saas',
    planOrSku: 'Scale Tier + Dedicated Worker Nodes',
    cadence: 'monthly',
    value: 3200,
    mrrEquivalent: 3200,
    tenureMonths: 11,
    riskScore: 68,
    riskLevel: 'high',
    primaryRiskReason: 'Invoice payment retry #2 failed',
    signals: [
      { name: 'Stripe webhook: charge.failed (Card Expired)', severity: 'high', detectedAt: '2 days ago' },
      { name: 'Billing contact notification bounced', severity: 'medium', detectedAt: 'Yesterday' }
    ],
    nextBillingDate: 'Sep 30, 2026',
    status: 'at_risk'
  },
  {
    id: 'saas_sub_204',
    name: 'Voxel Game Studios',
    email: 'billing@voxelgames.com',
    companyOrHandle: 'Nadia Petrov (Studio Director)',
    domain: 'saas',
    planOrSku: 'Developer Pro (10 Seats)',
    cadence: 'monthly',
    value: 490,
    mrrEquivalent: 490,
    tenureMonths: 24,
    riskScore: 52,
    riskLevel: 'moderate',
    primaryRiskReason: 'Feature adoption stalled on new release',
    signals: [
      { name: 'No activation of Realtime Sync add-on', severity: 'low', detectedAt: '12 days ago' },
      { name: 'Usage flattened over Q3', severity: 'medium', detectedAt: '20 days ago' }
    ],
    nextBillingDate: 'Oct 14, 2026',
    status: 'at_risk'
  },
  {
    id: 'saas_sub_205',
    name: 'Synthetix Data Labs',
    email: 'ops@synthetixdata.io',
    companyOrHandle: 'Dr. Aaron Vance',
    domain: 'saas',
    planOrSku: 'Enterprise Dedicated Cluster',
    cadence: 'annual',
    value: 48000,
    mrrEquivalent: 4000,
    tenureMonths: 30,
    riskScore: 14,
    riskLevel: 'healthy',
    primaryRiskReason: 'High health & power user expansion',
    signals: [],
    nextBillingDate: 'Mar 01, 2027',
    status: 'active'
  }
];

export const DTC_SAVE_OFFERS: SaveOffer[] = [
  {
    id: 'dtc_offer_pause',
    domain: 'dtc',
    title: 'Snooze Subscription (30 or 60 Days)',
    offerType: 'pause',
    description: 'Gives the customer time to enjoy their backlog without losing subscriber status or rewards.',
    incentiveValue: 'Skip 1 or 2 billing cycles with 1-click reactivation',
    targetReason: ['Too much coffee / backlogged with product', 'Temporary travel or moving', 'Budget review'],
    minimumTenureMonths: 1,
    acceptanceRate: 46.2,
    timesOffered: 1240,
    timesAccepted: 573,
    savedRevenue: 28400,
    marginCostEstimate: 0,
    status: 'active'
  },
  {
    id: 'dtc_offer_cadence_swap',
    domain: 'dtc',
    title: 'Switch Cadence to Every 4 or 6 Weeks',
    offerType: 'cadence_swap',
    description: 'Reduces shipment frequency from weekly/bi-weekly to prevent product accumulation while keeping regular orders.',
    incentiveValue: 'Adjust frequency + Keep locked-in tier perks',
    targetReason: ['Too much product / drinking less', 'Too expensive at current rate'],
    minimumTenureMonths: 2,
    acceptanceRate: 34.8,
    timesOffered: 980,
    timesAccepted: 341,
    savedRevenue: 17200,
    marginCostEstimate: 0,
    status: 'active'
  },
  {
    id: 'dtc_offer_discount_35',
    domain: 'dtc',
    title: '35% Off Next 2 Shipments',
    offerType: 'discount',
    description: 'High-intent economic relief targeted at price-sensitive subscribers attempting to cancel.',
    incentiveValue: '35% off the next 2 renewals automatically applied at checkout',
    targetReason: ['Too expensive / cutting monthly expenses', 'Found a cheaper alternative'],
    minimumTenureMonths: 3,
    acceptanceRate: 41.5,
    timesOffered: 810,
    timesAccepted: 336,
    savedRevenue: 22100,
    marginCostEstimate: 4200,
    status: 'active'
  },
  {
    id: 'dtc_offer_free_gift',
    domain: 'dtc',
    title: 'Complimentary Barista Accessories Bundle ($24 Value)',
    offerType: 'gift',
    description: 'Add a premium stainless steel scoop and sampler pack to their next box at zero extra cost.',
    incentiveValue: 'Free $24 physical accessory gift with next box',
    targetReason: ['Lost excitement / looking for something new', 'Quality not meeting expectation'],
    minimumTenureMonths: 4,
    acceptanceRate: 29.4,
    timesOffered: 450,
    timesAccepted: 132,
    savedRevenue: 7800,
    marginCostEstimate: 1056,
    status: 'active'
  }
];

export const SAAS_SAVE_OFFERS: SaveOffer[] = [
  {
    id: 'saas_offer_pause_billing',
    domain: 'saas',
    title: 'Freeze Billing for 60 Days (Preserve Workspace & Read-Only Access)',
    offerType: 'pause',
    description: 'Retain all integrations, custom schemas, and dashboards without data deletion or active charges.',
    incentiveValue: '0 charge for 60 days + instant unpause',
    targetReason: ['Project postponed or budget freeze', 'Switching tech stack temporarily', 'Seasonal lull'],
    minimumTenureMonths: 2,
    acceptanceRate: 39.1,
    timesOffered: 194,
    timesAccepted: 76,
    savedRevenue: 44200,
    marginCostEstimate: 0,
    status: 'active'
  },
  {
    id: 'saas_offer_csm_concierge',
    domain: 'saas',
    title: 'Complimentary Architecture & Optimization Sprint',
    offerType: 'concierge',
    description: 'Assign a Principal Solutions Architect for 2 bespoke integration sessions to unblock usage barriers.',
    incentiveValue: '2 dedicated 1-on-1 strategy sessions + VIP Slack channel',
    targetReason: ['Missing features / couldn’t get it configured', 'Too complicated for team to adopt'],
    minimumTenureMonths: 3,
    acceptanceRate: 31.8,
    timesOffered: 110,
    timesAccepted: 35,
    savedRevenue: 52000,
    marginCostEstimate: 3500,
    status: 'active'
  },
  {
    id: 'saas_offer_discount_40',
    domain: 'saas',
    title: '40% Discount for Next 3 Months',
    offerType: 'discount',
    description: 'Provide runway for cash-strapped accounts while their engineering or executive team finalizes procurement.',
    incentiveValue: '40% monthly credit applied to the upcoming 3 invoices',
    targetReason: ['Too expensive / CFO budget reduction', 'Pricing model does not scale with team'],
    minimumTenureMonths: 4,
    acceptanceRate: 37.6,
    timesOffered: 165,
    timesAccepted: 62,
    savedRevenue: 58900,
    marginCostEstimate: 11800,
    status: 'active'
  },
  {
    id: 'saas_offer_downgrade_flex',
    domain: 'saas',
    title: 'Downgrade to Flex Core Tier (Maintain Essential Seats)',
    offerType: 'downgrade',
    description: 'Prevent total churn by stepping the account down to a lighter tier rather than cancelling altogether.',
    incentiveValue: 'Keep key 5 seats at $120/mo instead of zeroing out',
    targetReason: ['Team downsized / don’t need 50 seats', 'CFO mandate to cut SaaS sprawl'],
    minimumTenureMonths: 2,
    acceptanceRate: 28.5,
    timesOffered: 140,
    timesAccepted: 40,
    savedRevenue: 31200,
    marginCostEstimate: 0,
    status: 'active'
  }
];

export const DTC_WINBACK_CAMPAIGNS: WinBackCampaign[] = [
  {
    id: 'dtc_camp_immediate',
    domain: 'dtc',
    name: 'Day 3 Post-Churn: The Open Door Check-In',
    triggerDelayDays: 3,
    status: 'active',
    subjectLine: 'Elena, we saved your roast preferences if you ever want to return',
    previewText: 'A quick goodbye note from our head roaster Marcus.',
    bodySnippet: 'We understand you needed a break from your Verve subscription. Your custom grind and tasting profile are safely stored in your account.',
    incentiveText: '$10 one-time credit to use on any single bag or sample bundle',
    discountCode: 'WELCOME-BACK-10',
    metrics: {
      targetedSubscribers: 420,
      sentCount: 418,
      openRate: 54.2,
      clickRate: 21.6,
      reactivationRate: 9.8,
      reclaimedRevenue: 7400
    },
    steps: [
      { id: 'step_1', dayOffset: 3, channel: 'email', title: 'Personalized Farewell & Credit', hook: 'Acknowledge cancellation + offer $10 no-strings credit' },
      { id: 'step_2', dayOffset: 5, channel: 'sms', title: '1-Click Reactivation Link', hook: 'Low friction SMS prompt with preserved discount' }
    ]
  },
  {
    id: 'dtc_camp_seasonal_drop',
    domain: 'dtc',
    name: 'Day 14: Limited Autumn Harvest Micro-Lot Drop',
    triggerDelayDays: 14,
    status: 'active',
    subjectLine: 'Before it sells out: exclusive access to our Ethiopian Yirgacheffe batch',
    previewText: 'Subscribers get first dibs, and we opened up a private allocation for you.',
    bodySnippet: 'Our roast team just brought in a rare anaerobic microlot from Sidama. We reserved a bag under your name if you want to resume with this roast.',
    incentiveText: 'Free priority shipping + 25% off this limited release',
    discountCode: 'HARVEST-RESERVE-25',
    metrics: {
      targetedSubscribers: 360,
      sentCount: 355,
      openRate: 48.9,
      clickRate: 18.2,
      reactivationRate: 12.4,
      reclaimedRevenue: 9800
    },
    steps: [
      { id: 'step_1', dayOffset: 14, channel: 'email', title: 'New Product Catalog Teaser', hook: 'Highlight exclusive new flavor unavailable when they left' }
    ]
  },
  {
    id: 'dtc_camp_day30_heavy',
    domain: 'dtc',
    name: 'Day 30: "We Miss You" 40% Off Comeback Package',
    triggerDelayDays: 30,
    status: 'active',
    subjectLine: '40% off to restart your morning ritual with us',
    previewText: 'It has been 30 days. Here is our highest reactivation savings code.',
    bodySnippet: 'Life gets busy, but fresh coffee shouldn’t be a chore. Reactivate your delivery today and lock in 40% off your next 2 boxes.',
    incentiveText: '40% off next 2 shipments + free travel mug',
    discountCode: 'COMEBACK-40-MUG',
    metrics: {
      targetedSubscribers: 290,
      sentCount: 288,
      openRate: 42.1,
      clickRate: 16.5,
      reactivationRate: 15.6,
      reclaimedRevenue: 12200
    },
    steps: [
      { id: 'step_1', dayOffset: 30, channel: 'email', title: 'Deep Incentive Anchor', hook: '40% discount + gift anchor' },
      { id: 'step_2', dayOffset: 33, channel: 'email', title: 'Final Code Expiration Notice', hook: '48-hour expiration reminder countdown' }
    ]
  }
];

export const SAAS_WINBACK_CAMPAIGNS: WinBackCampaign[] = [
  {
    id: 'saas_camp_exit_audit',
    domain: 'saas',
    name: 'Day 3 Post-Cancellation: Founder & Product Feedback',
    triggerDelayDays: 3,
    status: 'active',
    subjectLine: 'Quick question from our engineering lead regarding HyperScale',
    previewText: 'We noticed your team cancelled your subscription last week.',
    bodySnippet: 'I’m reaching out personally because your workload was one of our favorite benchmark cases. If there was a missing capability or performance issue, I would value 5 minutes of honest feedback.',
    incentiveText: '$100 Amazon gift card or donation for a 15-minute product chat',
    discountCode: 'VIP-REJOIN-FOUNDER',
    metrics: {
      targetedSubscribers: 42,
      sentCount: 42,
      openRate: 64.3,
      clickRate: 28.5,
      reactivationRate: 7.1,
      reclaimedRevenue: 9600
    },
    steps: [
      { id: 'step_1', dayOffset: 3, channel: 'email', title: 'Plain Text Founder Inquiry', hook: 'High-touch executive outreach asking for unvarnished feedback' }
    ]
  },
  {
    id: 'saas_camp_feature_drop',
    domain: 'saas',
    name: 'Day 21: "Shipped What You Requested" Feature Update',
    triggerDelayDays: 21,
    status: 'active',
    subjectLine: 'The multi-region clustering feature you asked about is now live',
    previewText: 'Major platform upgrades shipped in our Q3 changelog.',
    bodySnippet: 'When you cancelled, you mentioned performance bottlenecks under global concurrency. We rebuilt our edge routing engine, dropping p99 latency by 68%. Your previous workspace configuration is ready to test.',
    incentiveText: 'Free 30-day sandbox tier + 3 months at 50% discount upon return',
    discountCode: 'RELOAD-50',
    metrics: {
      targetedSubscribers: 38,
      sentCount: 38,
      openRate: 55.2,
      clickRate: 23.7,
      reactivationRate: 13.2,
      reclaimedRevenue: 18400
    },
    steps: [
      { id: 'step_1', dayOffset: 21, channel: 'email', title: 'Changelog Proof Email', hook: 'Demonstrate concrete engineering improvements solving their complaint' }
    ]
  },
  {
    id: 'saas_camp_annual_save',
    domain: 'saas',
    name: 'Day 45: Enterprise Comeback Contract (2 Months Free)',
    triggerDelayDays: 45,
    status: 'active',
    subjectLine: 'Reactivate HyperScale: 2 complimentary months on any annual agreement',
    previewText: 'Exclusive migration credits + guaranteed SLA uptime.',
    bodySnippet: 'Many engineering organizations that evaluated alternatives returned for our lower total cost of ownership. We are offering 2 complimentary months on any team or enterprise tier.',
    incentiveText: '2 months free ($4,800 value) + dedicated migration engineer',
    discountCode: 'ANNUAL-WINBACK-2MO',
    metrics: {
      targetedSubscribers: 32,
      sentCount: 32,
      openRate: 46.8,
      clickRate: 19.4,
      reactivationRate: 12.5,
      reclaimedRevenue: 24000
    },
    steps: [
      { id: 'step_1', dayOffset: 45, channel: 'email', title: 'Executive Win-Back Letter', hook: 'Substantial contractual discount paired with migration support' }
    ]
  }
];

export const DTC_COHORTS: CohortRow[] = [
  { cohortMonth: 'Oct 2025', startingSubscribers: 1850, startingMrr: 51800, retentionByMonth: [100, 84, 76, 71, 68, 65, 63, 62, 60, 59, 58, 57] },
  { cohortMonth: 'Nov 2025', startingSubscribers: 2100, startingMrr: 58800, retentionByMonth: [100, 82, 74, 69, 66, 64, 62, 60, 59, 57, 56] },
  { cohortMonth: 'Dec 2025', startingSubscribers: 2450, startingMrr: 68600, retentionByMonth: [100, 79, 71, 66, 63, 61, 59, 58, 56, 55] },
  { cohortMonth: 'Jan 2026', startingSubscribers: 2200, startingMrr: 61600, retentionByMonth: [100, 85, 78, 73, 70, 68, 66, 65, 64] },
  { cohortMonth: 'Feb 2026', startingSubscribers: 1950, startingMrr: 54600, retentionByMonth: [100, 86, 79, 75, 72, 70, 68, 67] },
  { cohortMonth: 'Mar 2026', startingSubscribers: 2050, startingMrr: 57400, retentionByMonth: [100, 87, 81, 77, 74, 72, 70] },
  { cohortMonth: 'Apr 2026', startingSubscribers: 2300, startingMrr: 64400, retentionByMonth: [100, 88, 82, 78, 75, 73] },
  { cohortMonth: 'May 2026', startingSubscribers: 2400, startingMrr: 67200, retentionByMonth: [100, 89, 83, 79, 76] },
  { cohortMonth: 'Jun 2026', startingSubscribers: 2550, startingMrr: 71400, retentionByMonth: [100, 90, 84, 80] },
  { cohortMonth: 'Jul 2026', startingSubscribers: 2700, startingMrr: 75600, retentionByMonth: [100, 91, 85] },
  { cohortMonth: 'Aug 2026', startingSubscribers: 2850, startingMrr: 79800, retentionByMonth: [100, 92] },
  { cohortMonth: 'Sep 2026', startingSubscribers: 3000, startingMrr: 84000, retentionByMonth: [100] }
];

export const SAAS_COHORTS: CohortRow[] = [
  { cohortMonth: 'Oct 2025', startingSubscribers: 120, startingMrr: 48000, retentionByMonth: [100, 96, 94, 93, 92, 91, 91, 90, 89, 89, 88, 88] },
  { cohortMonth: 'Nov 2025', startingSubscribers: 135, startingMrr: 54000, retentionByMonth: [100, 97, 95, 94, 93, 92, 91, 91, 90, 90, 89] },
  { cohortMonth: 'Dec 2025', startingSubscribers: 140, startingMrr: 56000, retentionByMonth: [100, 95, 93, 92, 91, 90, 89, 89, 88, 88] },
  { cohortMonth: 'Jan 2026', startingSubscribers: 155, startingMrr: 62000, retentionByMonth: [100, 97, 96, 95, 94, 93, 92, 92, 91] },
  { cohortMonth: 'Feb 2026', startingSubscribers: 160, startingMrr: 64000, retentionByMonth: [100, 98, 96, 95, 94, 93, 93, 92] },
  { cohortMonth: 'Mar 2026', startingSubscribers: 175, startingMrr: 70000, retentionByMonth: [100, 98, 97, 96, 95, 94, 93] },
  { cohortMonth: 'Apr 2026', startingSubscribers: 180, startingMrr: 72000, retentionByMonth: [100, 98, 97, 96, 95, 94] },
  { cohortMonth: 'May 2026', startingSubscribers: 190, startingMrr: 76000, retentionByMonth: [100, 99, 98, 97, 96] },
  { cohortMonth: 'Jun 2026', startingSubscribers: 205, startingMrr: 82000, retentionByMonth: [100, 99, 98, 97] },
  { cohortMonth: 'Jul 2026', startingSubscribers: 210, startingMrr: 84000, retentionByMonth: [100, 99, 98] },
  { cohortMonth: 'Aug 2026', startingSubscribers: 225, startingMrr: 90000, retentionByMonth: [100, 99] },
  { cohortMonth: 'Sep 2026', startingSubscribers: 235, startingMrr: 94000, retentionByMonth: [100] }
];

export const DTC_CHURN_REASONS = [
  { reason: 'Too much coffee / backlogged with beans', count: 684, percent: 38, recommendedOffer: 'Pause 30/60 Days or Cadence Swap' },
  { reason: 'Too expensive / cutting household expenses', count: 432, percent: 24, recommendedOffer: '35% Off Next 2 Shipments' },
  { reason: 'Want to try other roasters / taste fatigue', count: 288, percent: 16, recommendedOffer: 'Free Tasting Variety Bundle Swap' },
  { reason: 'Shipping delays or damaged delivery', count: 216, percent: 12, recommendedOffer: 'Priority Expedited Carrier + Gift' },
  { reason: 'Moving or temporary lifestyle change', count: 180, percent: 10, recommendedOffer: 'Snooze 90 Days with Address Update' }
];

export const SAAS_CHURN_REASONS = [
  { reason: 'Under-utilized / team not using enough seats', count: 48, percent: 36, recommendedOffer: 'Downgrade to Core Flex Plan' },
  { reason: 'CFO / executive budget cut across software', count: 36, percent: 27, recommendedOffer: '40% Discount for 3 Months' },
  { reason: 'Missing critical enterprise feature or integration', count: 24, percent: 18, recommendedOffer: 'CSM Architecture Review & Beta Access' },
  { reason: 'Switching to another competitor tool', count: 14, percent: 11, recommendedOffer: 'Price Match Guarantee + Contract Buyout' },
  { reason: 'Internal project shelved or team re-org', count: 11, percent: 8, recommendedOffer: '60-Day Billing Freeze with Read Access' }
];
