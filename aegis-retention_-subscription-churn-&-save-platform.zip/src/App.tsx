import React, { useState } from 'react';
import { DomainMode, Subscriber, SaveOffer, WinBackCampaign, RetentionMetrics } from './types/retention';
import { 
  DTC_METRICS, 
  SAAS_METRICS, 
  DTC_SIGNALS, 
  SAAS_SIGNALS, 
  DTC_SUBSCRIBERS, 
  SAAS_SUBSCRIBERS, 
  DTC_SAVE_OFFERS, 
  SAAS_SAVE_OFFERS, 
  DTC_WINBACK_CAMPAIGNS, 
  SAAS_WINBACK_CAMPAIGNS 
} from './data/mockData';
import { Header } from './components/Header';
import { Sidebar, TabKey } from './components/Sidebar';
import { OverviewView } from './components/OverviewView';
import { PredictiveChurnView } from './components/PredictiveChurnView';
import { SaveOffersStudio } from './components/SaveOffersStudio';
import { WinBackCampaignsView } from './components/WinBackCampaignsView';
import { CohortMatrixView } from './components/CohortMatrixView';
import { SettingsView } from './components/SettingsView';
import { CancellationSimulatorModal } from './components/CancellationSimulatorModal';
import { SubscriberDetailModal } from './components/SubscriberDetailModal';

export default function App() {
  const [currentDomain, setCurrentDomain] = useState<DomainMode>('dtc');
  const [currentTab, setCurrentTab] = useState<TabKey>('overview');

  // Interactive Live State
  const [dtcMetrics, setDtcMetrics] = useState<RetentionMetrics>({ ...DTC_METRICS });
  const [saasMetrics, setSaasMetrics] = useState<RetentionMetrics>({ ...SAAS_METRICS });

  const [subscribers, setSubscribers] = useState<Subscriber[]>([
    ...DTC_SUBSCRIBERS,
    ...SAAS_SUBSCRIBERS
  ]);

  const [saveOffers, setSaveOffers] = useState<SaveOffer[]>([
    ...DTC_SAVE_OFFERS,
    ...SAAS_SAVE_OFFERS
  ]);

  const [winBackCampaigns, setWinBackCampaigns] = useState<WinBackCampaign[]>([
    ...DTC_WINBACK_CAMPAIGNS,
    ...SAAS_WINBACK_CAMPAIGNS
  ]);

  // Modal States
  const [isCancelSimulatorOpen, setIsCancelSimulatorOpen] = useState(false);
  const [selectedSubForDetail, setSelectedSubForDetail] = useState<Subscriber | null>(null);

  const activeMetrics = currentDomain === 'dtc' ? dtcMetrics : saasMetrics;
  const activeSignals = currentDomain === 'dtc' ? DTC_SIGNALS : SAAS_SIGNALS;

  const currentAtRiskCount = subscribers.filter(
    s => s.domain === currentDomain && (s.riskLevel === 'critical' || s.riskLevel === 'high')
  ).length;

  // Handle Save Offer Accepted in Exit Flow
  const handleSubscriberSaved = (subscriberId: string, offer: SaveOffer) => {
    const targetSub = subscribers.find(s => s.id === subscriberId);
    if (!targetSub) return;

    // Update subscriber
    setSubscribers(prev => prev.map(s => {
      if (s.id === subscriberId) {
        return {
          ...s,
          riskScore: 18,
          riskLevel: 'healthy',
          status: 'saved',
          lastIntervention: {
            type: offer.title,
            date: 'Just now',
            outcome: 'Saved via Exit Flow'
          }
        };
      }
      return s;
    }));

    // Update Offer stats
    setSaveOffers(prev => prev.map(o => {
      if (o.id === offer.id) {
        return {
          ...o,
          timesAccepted: o.timesAccepted + 1,
          savedRevenue: o.savedRevenue + targetSub.value
        };
      }
      return o;
    }));

    // Update domain metrics
    if (currentDomain === 'dtc') {
      setDtcMetrics(m => ({
        ...m,
        savedRevenueThisMonth: m.savedRevenueThisMonth + targetSub.value,
        grossChurnRate: Math.max(0.1, Number((m.grossChurnRate - 0.1).toFixed(1)))
      }));
    } else {
      setSaasMetrics(m => ({
        ...m,
        savedRevenueThisMonth: m.savedRevenueThisMonth + targetSub.mrrEquivalent,
        grossChurnRate: Math.max(0.1, Number((m.grossChurnRate - 0.05).toFixed(2)))
      }));
    }
  };

  // Handle Subscriber Cancelled in Exit Flow
  const handleSubscriberCancelled = (subscriberId: string, reason: string) => {
    setSubscribers(prev => prev.map(s => {
      if (s.id === subscriberId) {
        return {
          ...s,
          status: 'churned',
          lastIntervention: {
            type: 'Cancellation Finalized',
            date: 'Just now',
            outcome: `Enrolled in Win-Back (${reason})`
          }
        };
      }
      return s;
    }));
  };

  // Handle Proactive Preemptive Intervention
  const handleApplyIntervention = (subscriberId: string, interventionType: string) => {
    setSubscribers(prev => prev.map(s => {
      if (s.id === subscriberId) {
        const newScore = Math.max(15, s.riskScore - 30);
        return {
          ...s,
          riskScore: newScore,
          riskLevel: newScore >= 60 ? 'high' : newScore >= 40 ? 'moderate' : 'healthy',
          lastIntervention: {
            type: interventionType,
            date: 'Just now',
            outcome: 'Proactive Intervention Dispatched'
          }
        };
      }
      return s;
    }));
  };

  // Handle Test Win-Back Reactivation
  const handleTriggerTestReactivation = (campaignId: string) => {
    const valueToAdd = currentDomain === 'dtc' ? 48 : 1250;

    setWinBackCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        return {
          ...c,
          metrics: {
            ...c.metrics,
            reactivationRate: Number((c.metrics.reactivationRate + 0.3).toFixed(1)),
            reclaimedRevenue: c.metrics.reclaimedRevenue + valueToAdd
          }
        };
      }
      return c;
    }));

    if (currentDomain === 'dtc') {
      setDtcMetrics(m => ({
        ...m,
        reclaimedRevenueThisMonth: m.reclaimedRevenueThisMonth + valueToAdd
      }));
    } else {
      setSaasMetrics(m => ({
        ...m,
        reclaimedRevenueThisMonth: m.reclaimedRevenueThisMonth + valueToAdd
      }));
    }
  };

  // Add custom save offer
  const handleAddOffer = (newOffer: Partial<SaveOffer>) => {
    setSaveOffers(prev => [newOffer as SaveOffer, ...prev]);
  };

  // Toggle offer status
  const handleToggleOfferStatus = (offerId: string) => {
    setSaveOffers(prev => prev.map(o => {
      if (o.id === offerId) {
        return {
          ...o,
          status: o.status === 'active' ? 'paused' : 'active'
        };
      }
      return o;
    }));
  };

  // Update Win-Back campaign
  const handleUpdateCampaign = (updated: WinBackCampaign) => {
    setWinBackCampaigns(prev => prev.map(c => c.id === updated.id ? updated : c));
  };

  // Reset simulated state
  const handleResetData = () => {
    setDtcMetrics({ ...DTC_METRICS });
    setSaasMetrics({ ...SAAS_METRICS });
    setSubscribers([...DTC_SUBSCRIBERS, ...SAAS_SUBSCRIBERS]);
    setSaveOffers([...DTC_SAVE_OFFERS, ...SAAS_SAVE_OFFERS]);
    setWinBackCampaigns([...DTC_WINBACK_CAMPAIGNS, ...SAAS_WINBACK_CAMPAIGNS]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar adhering to strict Top Bar Contract */}
      <Header
        currentDomain={currentDomain}
        onDomainChange={(d) => setCurrentDomain(d)}
        onOpenCancelSimulator={() => setIsCancelSimulatorOpen(true)}
        onResetData={handleResetData}
      />

      {/* Main Layout Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          currentDomain={currentDomain}
          atRiskCount={currentAtRiskCount}
        />

        {/* Workspace Canvas */}
        <main className="flex-1 p-6 overflow-y-auto max-w-7xl mx-auto w-full">
          {currentTab === 'overview' && (
            <OverviewView
              domain={currentDomain}
              metrics={activeMetrics}
              signals={activeSignals}
              subscribers={subscribers}
              onSelectSubscriber={(sub) => setSelectedSubForDetail(sub)}
              onOpenCancelSimulator={() => setIsCancelSimulatorOpen(true)}
              onNavigateToTab={(tab) => setCurrentTab(tab)}
            />
          )}

          {currentTab === 'predictive_churn' && (
            <PredictiveChurnView
              domain={currentDomain}
              subscribers={subscribers}
              onSelectSubscriber={(sub) => setSelectedSubForDetail(sub)}
              onOpenCancelSimulator={() => setIsCancelSimulatorOpen(true)}
              onQuickIntervene={(subId) => handleApplyIntervention(subId, 'Quick Preemptive Courtesy Credit')}
            />
          )}

          {currentTab === 'save_offers' && (
            <SaveOffersStudio
              domain={currentDomain}
              offers={saveOffers}
              onOpenCancelSimulator={() => setIsCancelSimulatorOpen(true)}
              onToggleOfferStatus={handleToggleOfferStatus}
              onAddOffer={handleAddOffer}
            />
          )}

          {currentTab === 'win_back' && (
            <WinBackCampaignsView
              domain={currentDomain}
              campaigns={winBackCampaigns}
              onTriggerTestReactivation={handleTriggerTestReactivation}
              onUpdateCampaign={handleUpdateCampaign}
            />
          )}

          {currentTab === 'cohort_matrix' && (
            <CohortMatrixView
              domain={currentDomain}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              domain={currentDomain}
            />
          )}
        </main>
      </div>

      {/* Interactive Live Modals */}
      <CancellationSimulatorModal
        isOpen={isCancelSimulatorOpen}
        onClose={() => setIsCancelSimulatorOpen(false)}
        domain={currentDomain}
        subscribers={subscribers}
        onSubscriberSaved={handleSubscriberSaved}
        onSubscriberCancelled={handleSubscriberCancelled}
      />

      <SubscriberDetailModal
        subscriber={selectedSubForDetail}
        onClose={() => setSelectedSubForDetail(null)}
        domain={currentDomain}
        onApplyIntervention={handleApplyIntervention}
        onLaunchSimulatedCancel={(subId) => {
          setIsCancelSimulatorOpen(true);
        }}
      />
    </div>
  );
}
