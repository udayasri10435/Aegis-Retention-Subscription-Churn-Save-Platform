import React from 'react';
import { 
  BarChart3, 
  ShieldAlert, 
  Gift, 
  Mail, 
  Layers, 
  Sliders, 
  ArrowUpRight,
  TrendingDown
} from 'lucide-react';
import { DomainMode } from '../types/retention';

export type TabKey = 'overview' | 'predictive_churn' | 'save_offers' | 'win_back' | 'cohort_matrix' | 'settings';

interface SidebarProps {
  currentTab: TabKey;
  onSelectTab: (tab: TabKey) => void;
  currentDomain: DomainMode;
  atRiskCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  currentDomain,
  atRiskCount
}) => {
  const navItems: { key: TabKey; label: string; icon: React.ReactNode; badge?: string }[] = [
    {
      key: 'overview',
      label: 'Command Center',
      icon: <BarChart3 className="w-4 h-4" />
    },
    {
      key: 'predictive_churn',
      label: 'Predictive Churn Ledger',
      icon: <ShieldAlert className="w-4 h-4" />,
      badge: atRiskCount > 0 ? `${atRiskCount} Alert` : undefined
    },
    {
      key: 'save_offers',
      label: 'Save Offers & Exit Flow',
      icon: <Gift className="w-4 h-4" />
    },
    {
      key: 'win_back',
      label: 'Win-Back Sequences',
      icon: <Mail className="w-4 h-4" />
    },
    {
      key: 'cohort_matrix',
      label: 'Cohorts & Root Causes',
      icon: <Layers className="w-4 h-4" />
    },
    {
      key: 'settings',
      label: 'Integrations & Rules',
      icon: <Sliders className="w-4 h-4" />
    }
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none">
      <div className="p-4 space-y-6">
        {/* Workspace Context Card */}
        <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800 text-xs">
          <div className="text-slate-400 font-medium mb-1">Active Subscription Environment</div>
          <div className="font-semibold text-slate-100 flex items-center justify-between">
            <span>{currentDomain === 'dtc' ? 'Verve Botanic (DTC)' : 'HyperScale Cloud (SaaS)'}</span>
            <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
              {currentDomain}
            </span>
          </div>
          <div className="mt-2 text-slate-400 text-[11px] flex items-center gap-1.5">
            <span>Billing Sync:</span>
            <span className="text-emerald-400 font-mono font-medium">Stripe + Recharge</span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1">
          <div className="px-3 pb-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Retention Modules
          </div>
          {navItems.map((item) => {
            const isActive = currentTab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => onSelectTab(item.key)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={isActive ? 'text-indigo-400' : 'text-slate-400'}>{item.icon}</span>
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="px-1.5 py-0.5 text-[10px] font-mono font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Quick Footnote & Status */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            Webhook Ingestion OK
          </span>
          <span className="font-mono text-[11px] text-slate-400">0 dropped</span>
        </div>
        <div className="mt-2 text-[11px] text-slate-400 leading-tight">
          Aegis Engine v2.8 · Churn deflection active
        </div>
      </div>
    </aside>
  );
};
