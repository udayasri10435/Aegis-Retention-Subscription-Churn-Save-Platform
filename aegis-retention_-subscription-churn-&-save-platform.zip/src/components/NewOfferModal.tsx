import React, { useState } from 'react';
import { X, Gift, Percent, PauseCircle, CheckCircle, Sparkles } from 'lucide-react';
import { DomainMode, SaveOffer } from '../types/retention';

interface NewOfferModalProps {
  isOpen: boolean;
  onClose: () => void;
  domain: DomainMode;
  onSaveOffer: (offer: Partial<SaveOffer>) => void;
}

export const NewOfferModal: React.FC<NewOfferModalProps> = ({
  isOpen,
  onClose,
  domain,
  onSaveOffer
}) => {
  if (!isOpen) return null;

  const [title, setTitle] = useState('');
  const [offerType, setOfferType] = useState<SaveOffer['offerType']>('discount');
  const [incentiveValue, setIncentiveValue] = useState('');
  const [description, setDescription] = useState('');
  const [targetReason, setTargetReason] = useState(
    domain === 'dtc' ? 'Too expensive / cutting household expenses' : 'CFO / executive budget cut across software'
  );
  const [minimumTenureMonths, setMinimumTenureMonths] = useState(2);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !incentiveValue.trim()) return;

    onSaveOffer({
      id: `${domain}_offer_${Date.now()}`,
      domain,
      title: title.trim(),
      offerType,
      incentiveValue: incentiveValue.trim(),
      description: description.trim() || 'Dynamic retention save offer configured via Aegis Studio.',
      targetReason: [targetReason],
      minimumTenureMonths,
      acceptanceRate: 35.0,
      timesOffered: 0,
      timesAccepted: 0,
      savedRevenue: 0,
      marginCostEstimate: 0,
      status: 'active'
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <h2 className="text-sm font-semibold text-white">Create Targeted Save Offer</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-medium mb-1">Offer Title</label>
            <input
              type="text"
              required
              placeholder={domain === 'dtc' ? 'e.g. 30% Off Next 2 Shipments' : 'e.g. 50% Relief Discount for 3 Months'}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Offer Mechanism</label>
              <select
                value={offerType}
                onChange={(e) => setOfferType(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="discount">Price Discount (%)</option>
                <option value="pause">Delivery / Billing Pause</option>
                <option value="cadence_swap">Frequency / Cadence Swap</option>
                <option value="downgrade">Tier Downgrade</option>
                <option value="concierge">Dedicated Concierge / CSM</option>
                <option value="gift">Complimentary Gift / Accessory</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Incentive Payload</label>
              <input
                type="text"
                required
                placeholder="e.g. 35% off next 2 boxes"
                value={incentiveValue}
                onChange={(e) => setIncentiveValue(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Target Exit Reason Trigger</label>
            <select
              value={targetReason}
              onChange={(e) => setTargetReason(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              {domain === 'dtc' ? (
                <>
                  <option value="Too expensive / cutting household expenses">Too expensive / cutting household expenses</option>
                  <option value="Too much coffee / backlogged with product">Too much coffee / backlogged with product</option>
                  <option value="Want to try other roasters / taste fatigue">Want to try other roasters / taste fatigue</option>
                  <option value="Shipping delays or damaged delivery">Shipping delays or damaged delivery</option>
                  <option value="Temporary pause or moving">Temporary pause or moving</option>
                </>
              ) : (
                <>
                  <option value="CFO / executive budget cut across software">CFO / executive budget cut across software</option>
                  <option value="Under-utilized / team not using enough seats">Under-utilized / team not using enough seats</option>
                  <option value="Missing critical enterprise feature or integration">Missing critical enterprise feature or integration</option>
                  <option value="Switching to another competitor tool">Switching to another competitor tool</option>
                  <option value="Internal project shelved or team re-org">Internal project shelved or team re-org</option>
                </>
              )}
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Subscriber Description / Headline Copy</label>
            <textarea
              rows={3}
              placeholder="Copy shown to subscriber during exit flow..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 resize-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow-sm transition-colors"
            >
              Deploy Save Offer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
