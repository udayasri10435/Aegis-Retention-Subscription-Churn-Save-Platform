import React, { useState } from 'react';
import { 
  X, 
  AlertTriangle, 
  ShieldAlert, 
  TrendingDown, 
  Clock, 
  Mail, 
  CheckCircle, 
  Zap, 
  Calendar,
  DollarSign,
  ArrowRight
} from 'lucide-react';
import { Subscriber, DomainMode } from '../types/retention';

interface SubscriberDetailModalProps {
  subscriber: Subscriber | null;
  onClose: () => void;
  domain: DomainMode;
  onApplyIntervention: (subscriberId: string, interventionType: string) => void;
  onLaunchSimulatedCancel: (subscriberId: string) => void;
}

export const SubscriberDetailModal: React.FC<SubscriberDetailModalProps> = ({
  subscriber,
  onClose,
  domain,
  onApplyIntervention,
  onLaunchSimulatedCancel
}) => {
  if (!subscriber) return null;

  const [interventionApplied, setInterventionApplied] = useState(false);
  const [selectedIntervention, setSelectedIntervention] = useState(
    domain === 'dtc' ? 'Proactive 20% Courtesy Credit on Next Shipment' : 'Complimentary Executive CSM Strategy Call'
  );

  const handleTrigger = () => {
    onApplyIntervention(subscriber.id, selectedIntervention);
    setInterventionApplied(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-slate-200">
              {subscriber.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-semibold text-white">{subscriber.name}</h3>
                <span className={`px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded ${
                  subscriber.riskLevel === 'critical' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                  subscriber.riskLevel === 'high' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                  'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {subscriber.riskScore}% Churn Probability
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                {subscriber.email} {subscriber.companyOrHandle ? `· ${subscriber.companyOrHandle}` : ''}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Key Metric Highlights */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
              <div className="text-slate-400 font-medium">Subscription Plan</div>
              <div className="text-sm font-semibold text-white mt-1 truncate">{subscriber.planOrSku}</div>
              <div className="text-[11px] text-slate-400 mt-0.5 capitalize">{subscriber.cadence} billing</div>
            </div>
            <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
              <div className="text-slate-400 font-medium">Contract / MRR Value</div>
              <div className="text-sm font-mono font-semibold text-white mt-1 tabular-nums">
                ${subscriber.value} <span className="text-slate-400 text-xs font-normal">({subscriber.mrrEquivalent} MRR)</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">Tenure: {subscriber.tenureMonths} months</div>
            </div>
            <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
              <div className="text-slate-400 font-medium">Next Cycle Date</div>
              <div className="text-sm font-semibold text-slate-200 mt-1">{subscriber.nextBillingDate}</div>
              <div className="text-[11px] text-amber-400 mt-0.5">Urgent intervention window</div>
            </div>
          </div>

          {/* Leading Signals Triggering Churn Score */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                Active Risk Signals (Feature Attribution)
              </h4>
              <span className="text-[11px] text-slate-400">Total Weight: {subscriber.riskScore}/100</span>
            </div>

            {subscriber.signals.length === 0 ? (
              <div className="p-4 bg-slate-950/40 border border-slate-800 rounded-xl text-slate-400 text-center">
                No acute negative telemetry detected. Account exhibits healthy engagement habits.
              </div>
            ) : (
              <div className="space-y-2">
                {subscriber.signals.map((sig, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-2 h-2 rounded-full ${
                        sig.severity === 'high' ? 'bg-rose-500' :
                        sig.severity === 'medium' ? 'bg-amber-500' : 'bg-yellow-500'
                      }`} />
                      <div>
                        <div className="font-medium text-slate-200">{sig.name}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>Detected {sig.detectedAt}</span>
                        </div>
                      </div>
                    </div>

                    <span className={`px-2 py-0.5 text-[10px] font-mono uppercase font-bold rounded ${
                      sig.severity === 'high' ? 'bg-rose-500/10 text-rose-300' : 'bg-amber-500/10 text-amber-300'
                    }`}>
                      {sig.severity} impact
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Proactive Pre-Cancellation Intervention */}
          <div className="p-4 bg-indigo-950/30 border border-indigo-500/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-semibold text-indigo-300 flex items-center gap-1.5 text-xs">
                <Zap className="w-4 h-4 text-indigo-400" />
                Preemptive Retention Intervention
              </div>
              <span className="text-[11px] text-slate-400">Intercept before cancellation page</span>
            </div>

            <p className="text-slate-300 text-xs leading-relaxed">
              Dispatch an automated, non-invasive retention stimulus immediately to reverse churn trajectory before renewal date.
            </p>

            {interventionApplied ? (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-lg flex items-center gap-2 text-emerald-300 text-xs">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                <div>
                  <span className="font-semibold">Intervention Dispatched!</span> Subscriber status updated to "Intervened / Monitoring". Risk score reduced by 30%.
                </div>
              </div>
            ) : (
              <div className="space-y-3 pt-1">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-medium text-slate-300">Select Proactive Action:</label>
                  <select
                    value={selectedIntervention}
                    onChange={(e) => setSelectedIntervention(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:border-indigo-500"
                  >
                    {domain === 'dtc' ? (
                      <>
                        <option value="Proactive 20% Courtesy Credit on Next Shipment">
                          Proactive 20% Courtesy Credit on Next Shipment
                        </option>
                        <option value="Auto-Suggest 30-Day Delivery Snooze via Email/SMS">
                          Auto-Suggest 30-Day Delivery Snooze via Email/SMS
                        </option>
                        <option value="Send Free Tasting Sampler ($18 value)">
                          Send Free Tasting Sampler ($18 value)
                        </option>
                        <option value="Switch Cadence to 4-Week Cycle">
                          Switch Cadence to 4-Week Cycle
                        </option>
                      </>
                    ) : (
                      <>
                        <option value="Complimentary Executive CSM Strategy Call">
                          Complimentary Executive CSM Strategy Call
                        </option>
                        <option value="Apply 30% Relief Credit for Next Quarter">
                          Apply 30% Relief Credit for Next Quarter
                        </option>
                        <option value="Grant 60-Day Billing Freeze with Read-Only State">
                          Grant 60-Day Billing Freeze with Read-Only State
                        </option>
                        <option value="Downgrade to Flex Core Tier">
                          Downgrade to Flex Core Tier
                        </option>
                      </>
                    )}
                  </select>
                </div>

                <div className="flex items-center gap-3 pt-1">
                  <button
                    onClick={handleTrigger}
                    className="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5 text-xs"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Execute Preemptive Intervention</span>
                  </button>

                  <button
                    onClick={() => {
                      onClose();
                      onLaunchSimulatedCancel(subscriber.id);
                    }}
                    className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-medium rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5 text-xs whitespace-nowrap"
                  >
                    <span>Test Exit Flow</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/40 flex items-center justify-between text-slate-400 text-xs">
          <span>Subscriber ID: <span className="font-mono text-slate-300">{subscriber.id}</span></span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
