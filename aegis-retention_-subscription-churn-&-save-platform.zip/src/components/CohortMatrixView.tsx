import React from 'react';
import { 
  Layers, 
  TrendingDown, 
  AlertCircle, 
  CreditCard, 
  HelpCircle, 
  CheckCircle,
  BarChart3
} from 'lucide-react';
import { DomainMode, CohortRow } from '../types/retention';
import { 
  DTC_COHORTS, 
  SAAS_COHORTS, 
  DTC_CHURN_REASONS, 
  SAAS_CHURN_REASONS 
} from '../data/mockData';

interface CohortMatrixViewProps {
  domain: DomainMode;
}

export const CohortMatrixView: React.FC<CohortMatrixViewProps> = ({ domain }) => {
  const cohorts: CohortRow[] = domain === 'dtc' ? DTC_COHORTS : SAAS_COHORTS;
  const churnReasons = domain === 'dtc' ? DTC_CHURN_REASONS : SAAS_CHURN_REASONS;

  // Calculate cell background color based on retention %
  const getCellColor = (value: number) => {
    if (value >= 90) return 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30';
    if (value >= 80) return 'bg-emerald-950/40 text-emerald-400 border-emerald-500/20';
    if (value >= 70) return 'bg-indigo-950/40 text-indigo-300 border-indigo-500/20';
    if (value >= 60) return 'bg-amber-950/40 text-amber-300 border-amber-500/20';
    return 'bg-rose-950/40 text-rose-300 border-rose-500/20';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Cohort Retention & Root Cause Diagnostics
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            12-month subscriber longevity tracking and Pareto root-cause cancellation telemetry.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg">
            <span className="text-slate-400">Average Month-3 Retention: </span>
            <span className="font-mono font-bold text-emerald-400">{domain === 'dtc' ? '74.2%' : '94.8%'}</span>
          </div>
          <div className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg">
            <span className="text-slate-400">Average Month-12 Retention: </span>
            <span className="font-mono font-bold text-indigo-300">{domain === 'dtc' ? '56.0%' : '88.0%'}</span>
          </div>
        </div>
      </div>

      {/* Cohort Heatmap Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-tight">
              Subscriber Retention Heatmap by Cohort
            </h2>
            <p className="text-xs text-slate-400">
              Percentage of subscribers active at month M+N following initial acquisition.
            </p>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-emerald-700"></span>
              &gt;85%
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-indigo-700"></span>
              70–84%
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-rose-700"></span>
              &lt;70%
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-center border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                <th className="py-2.5 px-3 text-left">Cohort</th>
                <th className="py-2.5 px-3 text-left">Base</th>
                <th className="py-2.5 px-3">M0</th>
                <th className="py-2.5 px-3">M1</th>
                <th className="py-2.5 px-3">M2</th>
                <th className="py-2.5 px-3">M3</th>
                <th className="py-2.5 px-3">M4</th>
                <th className="py-2.5 px-3">M5</th>
                <th className="py-2.5 px-3">M6</th>
                <th className="py-2.5 px-3">M7</th>
                <th className="py-2.5 px-3">M8</th>
                <th className="py-2.5 px-3">M9</th>
                <th className="py-2.5 px-3">M10</th>
                <th className="py-2.5 px-3">M11</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40">
              {cohorts.map((cohort, idx) => (
                <tr key={idx} className="hover:bg-slate-850/50 transition-colors">
                  <td className="py-2.5 px-3 text-left font-semibold text-slate-200 whitespace-nowrap">
                    {cohort.cohortMonth}
                  </td>
                  <td className="py-2.5 px-3 text-left font-mono text-slate-400 whitespace-nowrap tabular-nums">
                    {cohort.startingSubscribers.toLocaleString()}
                  </td>
                  {[...Array(12)].map((_, monthIdx) => {
                    const val = cohort.retentionByMonth[monthIdx];
                    if (val === undefined) {
                      return (
                        <td key={monthIdx} className="py-2.5 px-2 text-slate-700 font-mono text-[11px]">
                          —
                        </td>
                      );
                    }
                    return (
                      <td key={monthIdx} className="py-2 px-1">
                        <div
                          className={`py-1 px-1.5 rounded font-mono font-medium text-[11px] tabular-nums border ${getCellColor(
                            val
                          )}`}
                        >
                          {val}%
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Two Column Bottom Grid: Churn Reasons Pareto & Voluntary/Involuntary Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Churn Reasons Pareto Distribution */}
        <div className="lg:col-span-8 p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white tracking-tight">
                Cancellation Root-Cause Pareto Breakdown
              </h2>
              <p className="text-xs text-slate-400">
                Primary reasons selected by subscribers upon cancellation in exit flow.
              </p>
            </div>
            <span className="text-[11px] font-mono text-indigo-400">
              {churnReasons.reduce((a, b) => a + b.count, 0)} Total Responses
            </span>
          </div>

          <div className="space-y-3 pt-1">
            {churnReasons.map((item, idx) => (
              <div
                key={idx}
                className="p-3.5 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-slate-200">
                    <span className="text-slate-400 font-mono mr-2">{idx + 1}.</span>
                    {item.reason}
                  </div>
                  <div className="flex items-center gap-3 font-mono">
                    <span className="text-slate-400">{item.count} users</span>
                    <span className="font-bold text-white tabular-nums">{item.percent}%</span>
                  </div>
                </div>

                {/* Bar */}
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      idx === 0 ? 'bg-indigo-500' :
                      idx === 1 ? 'bg-violet-500' :
                      idx === 2 ? 'bg-cyan-500' : 'bg-slate-600'
                    }`}
                    style={{ width: `${item.percent * 2}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5">
                  <span className="flex items-center gap-1.5 text-indigo-400">
                    <CheckCircle className="w-3 h-3" />
                    <span>Recommended Counter-Offer:</span>
                  </span>
                  <span className="font-medium text-slate-300">{item.recommendedOffer}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Voluntary vs Involuntary Churn Split */}
        <div className="lg:col-span-4 p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <h2 className="text-sm font-semibold text-white tracking-tight">
                Voluntary vs Involuntary Churn
              </h2>
              <p className="text-xs text-slate-400">
                Intentional cancellation vs payment card failure.
              </p>
            </div>

            {/* Breakdown Graphic */}
            <div className="space-y-3">
              <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">Voluntary Churn</span>
                  <span className="font-mono font-bold text-indigo-400">76.2%</span>
                </div>
                <div className="text-[11px] text-slate-400 leading-relaxed">
                  Subscribers who actively navigated to cancellation and confirmed termination.
                </div>
                <div className="text-[10px] font-mono text-emerald-400">
                  Targeted by Save Offers Studio & Exit Flow
                </div>
              </div>

              <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">Involuntary Churn</span>
                  <span className="font-mono font-bold text-rose-400">23.8%</span>
                </div>
                <div className="text-[11px] text-slate-400 leading-relaxed">
                  Failed credit cards, expired credentials, and bank recharge declines.
                </div>
                <div className="text-[10px] font-mono text-indigo-300">
                  Recovered by Smart Dunning Engine (71.4% recovery)
                </div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-indigo-950/20 border border-indigo-500/20 rounded-xl text-xs space-y-1">
            <div className="font-semibold text-indigo-300">Smart Dunning Status</div>
            <div className="text-slate-400 text-[11px]">
              Adaptive retry cadence active (Day 1, 3, 5, 7 + automated card updater API).
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
