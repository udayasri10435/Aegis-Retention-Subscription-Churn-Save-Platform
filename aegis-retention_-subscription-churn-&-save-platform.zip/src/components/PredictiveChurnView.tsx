import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  ShieldAlert, 
  AlertTriangle, 
  Zap, 
  Play, 
  ArrowRight, 
  Clock, 
  DollarSign,
  ChevronRight,
  TrendingDown,
  CheckCircle2
} from 'lucide-react';
import { Subscriber, DomainMode, RiskLevel } from '../types/retention';

interface PredictiveChurnViewProps {
  domain: DomainMode;
  subscribers: Subscriber[];
  onSelectSubscriber: (subscriber: Subscriber) => void;
  onOpenCancelSimulator: (subscriberId?: string) => void;
  onQuickIntervene: (subscriberId: string) => void;
}

export const PredictiveChurnView: React.FC<PredictiveChurnViewProps> = ({
  domain,
  subscribers,
  onSelectSubscriber,
  onOpenCancelSimulator,
  onQuickIntervene
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRiskFilter, setSelectedRiskFilter] = useState<'all' | RiskLevel>('all');

  const domainSubscribers = subscribers.filter(s => s.domain === domain);

  const filteredSubscribers = domainSubscribers.filter(sub => {
    const matchesSearch = 
      sub.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.planOrSku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (sub.companyOrHandle && sub.companyOrHandle.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesRisk = selectedRiskFilter === 'all' || sub.riskLevel === selectedRiskFilter;

    return matchesSearch && matchesRisk;
  });

  const criticalCount = domainSubscribers.filter(s => s.riskLevel === 'critical').length;
  const highCount = domainSubscribers.filter(s => s.riskLevel === 'high').length;
  const totalMrrAtRisk = domainSubscribers
    .filter(s => s.riskLevel === 'critical' || s.riskLevel === 'high')
    .reduce((sum, s) => sum + s.mrrEquivalent, 0);

  return (
    <div className="space-y-6">
      {/* Header & Context */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Predictive Churn Risk Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Continuous hazard scoring evaluating churn propensity 30–60 days ahead of billing renewal.
          </p>
        </div>

        {/* High Level Quick Stat Badges */}
        <div className="flex items-center gap-3 text-xs">
          <div className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg">
            <span className="text-slate-400">Total Evaluated: </span>
            <span className="font-mono font-bold text-white">{domainSubscribers.length} accounts</span>
          </div>
          <div className="px-3 py-1.5 bg-rose-950/40 border border-rose-500/30 rounded-lg">
            <span className="text-rose-300">High Risk MRR: </span>
            <span className="font-mono font-bold text-rose-200">${totalMrrAtRisk.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by name, email, plan..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/70 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Segmented Risk Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 text-xs w-full md:w-auto overflow-x-auto">
          <button
            onClick={() => setSelectedRiskFilter('all')}
            className={`px-3 py-1.5 font-medium rounded-md transition-all whitespace-nowrap ${
              selectedRiskFilter === 'all'
                ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Accounts ({domainSubscribers.length})
          </button>
          <button
            onClick={() => setSelectedRiskFilter('critical')}
            className={`px-3 py-1.5 font-medium rounded-md transition-all whitespace-nowrap ${
              selectedRiskFilter === 'critical'
                ? 'bg-rose-600 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-rose-300'
            }`}
          >
            Critical ({criticalCount})
          </button>
          <button
            onClick={() => setSelectedRiskFilter('high')}
            className={`px-3 py-1.5 font-medium rounded-md transition-all whitespace-nowrap ${
              selectedRiskFilter === 'high'
                ? 'bg-amber-600 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-amber-300'
            }`}
          >
            High ({highCount})
          </button>
          <button
            onClick={() => setSelectedRiskFilter('moderate')}
            className={`px-3 py-1.5 font-medium rounded-md transition-all whitespace-nowrap ${
              selectedRiskFilter === 'moderate'
                ? 'bg-yellow-600 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Moderate
          </button>
          <button
            onClick={() => setSelectedRiskFilter('healthy')}
            className={`px-3 py-1.5 font-medium rounded-md transition-all whitespace-nowrap ${
              selectedRiskFilter === 'healthy'
                ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-emerald-300'
            }`}
          >
            Healthy
          </button>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3.5 px-4">Subscriber / Account</th>
                <th className="py-3.5 px-4">Plan & Cadence</th>
                <th className="py-3.5 px-4">Value (MRR)</th>
                <th className="py-3.5 px-4">Churn Probability</th>
                <th className="py-3.5 px-4">Primary Leading Indicator</th>
                <th className="py-3.5 px-4">Next Renewal</th>
                <th className="py-3.5 px-4 text-right">Intervention</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredSubscribers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    No subscribers found matching the current search and filter.
                  </td>
                </tr>
              ) : (
                filteredSubscribers.map((sub) => {
                  const isCritical = sub.riskLevel === 'critical';
                  const isHigh = sub.riskLevel === 'high';

                  return (
                    <tr 
                      key={sub.id}
                      onClick={() => onSelectSubscriber(sub)}
                      className="hover:bg-slate-850/80 transition-colors cursor-pointer group"
                    >
                      {/* Subscriber Info */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-slate-200 shrink-0">
                            {sub.name.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div>
                            <div className="font-semibold text-white group-hover:text-indigo-300 transition-colors">
                              {sub.name}
                            </div>
                            <div className="text-[11px] text-slate-400 truncate max-w-[180px]">
                              {sub.email}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Plan & Cadence */}
                      <td className="py-3.5 px-4">
                        <div className="text-slate-200 font-medium truncate max-w-[190px]">
                          {sub.planOrSku}
                        </div>
                        <div className="text-[11px] text-slate-400 capitalize">
                          {sub.cadence} · {sub.tenureMonths} mo tenure
                        </div>
                      </td>

                      {/* Value / MRR */}
                      <td className="py-3.5 px-4">
                        <div className="font-mono font-bold text-white tabular-nums">
                          ${sub.value}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          (${sub.mrrEquivalent}/mo MRR)
                        </div>
                      </td>

                      {/* Churn Probability */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1.5 w-32">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className={`font-mono font-bold tabular-nums ${
                              isCritical ? 'text-rose-400' :
                              isHigh ? 'text-amber-400' :
                              sub.riskLevel === 'moderate' ? 'text-yellow-400' : 'text-emerald-400'
                            }`}>
                              {sub.riskScore}%
                            </span>
                            <span className="text-[10px] uppercase font-mono text-slate-400">
                              {sub.riskLevel}
                            </span>
                          </div>
                          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                isCritical ? 'bg-rose-500' :
                                isHigh ? 'bg-amber-500' :
                                sub.riskLevel === 'moderate' ? 'bg-yellow-500' : 'bg-emerald-500'
                              }`}
                              style={{ width: `${sub.riskScore}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      {/* Primary Leading Indicator */}
                      <td className="py-3.5 px-4">
                        <div className="text-slate-300 font-medium max-w-[200px] truncate">
                          {sub.primaryRiskReason}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                          <span>{sub.signals.length} active risk telemetries</span>
                        </div>
                      </td>

                      {/* Next Renewal */}
                      <td className="py-3.5 px-4">
                        <div className="text-slate-200 font-medium">
                          {sub.nextBillingDate}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {isCritical ? (
                            <span className="text-rose-400 font-medium">Urgent attention</span>
                          ) : (
                            <span>Standard cycle</span>
                          )}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => onQuickIntervene(sub.id)}
                            title="Execute proactive save intervention"
                            className="p-1.5 text-indigo-400 hover:text-white bg-indigo-950/40 hover:bg-indigo-600 border border-indigo-500/30 rounded-lg transition-colors"
                          >
                            <Zap className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onOpenCancelSimulator(sub.id)}
                            title="Simulate subscriber exit flow"
                            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
                          >
                            <Play className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onSelectSubscriber(sub)}
                            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
