import React, { useState } from 'react';
import { 
  Mail, 
  RotateCcw, 
  Send, 
  Clock, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  Smartphone, 
  Percent, 
  Check, 
  TrendingUp,
  Tag
} from 'lucide-react';
import { DomainMode, WinBackCampaign } from '../types/retention';

interface WinBackCampaignsViewProps {
  domain: DomainMode;
  campaigns: WinBackCampaign[];
  onTriggerTestReactivation: (campaignId: string) => void;
  onUpdateCampaign: (updated: WinBackCampaign) => void;
}

export const WinBackCampaignsView: React.FC<WinBackCampaignsViewProps> = ({
  domain,
  campaigns,
  onTriggerTestReactivation,
  onUpdateCampaign
}) => {
  const domainCampaigns = campaigns.filter(c => c.domain === domain);
  const [selectedCampId, setSelectedCampId] = useState<string>(domainCampaigns[0]?.id || '');
  const activeCampaign = domainCampaigns.find(c => c.id === selectedCampId) || domainCampaigns[0];

  const [subjectLine, setSubjectLine] = useState(activeCampaign?.subjectLine || '');
  const [previewText, setPreviewText] = useState(activeCampaign?.previewText || '');
  const [bodySnippet, setBodySnippet] = useState(activeCampaign?.bodySnippet || '');
  const [discountCode, setDiscountCode] = useState(activeCampaign?.discountCode || '');
  const [isSavedAlert, setIsSavedAlert] = useState(false);
  const [testSentAlert, setTestSentAlert] = useState(false);

  // Sync state if activeCampaign changes
  React.useEffect(() => {
    if (activeCampaign) {
      setSubjectLine(activeCampaign.subjectLine);
      setPreviewText(activeCampaign.previewText);
      setBodySnippet(activeCampaign.bodySnippet);
      setDiscountCode(activeCampaign.discountCode || '');
    }
  }, [activeCampaign?.id]);

  const handleSaveDraft = () => {
    if (!activeCampaign) return;
    const updated: WinBackCampaign = {
      ...activeCampaign,
      subjectLine,
      previewText,
      bodySnippet,
      discountCode
    };
    onUpdateCampaign(updated);
    setIsSavedAlert(true);
    setTimeout(() => setIsSavedAlert(false), 2500);
  };

  const handleTestReactivation = () => {
    if (!activeCampaign) return;
    onTriggerTestReactivation(activeCampaign.id);
    setTestSentAlert(true);
    setTimeout(() => setTestSentAlert(false), 3000);
  };

  const totalReclaimed = domainCampaigns.reduce((acc, c) => acc + c.metrics.reclaimedRevenue, 0);
  const avgReactivation = (
    domainCampaigns.reduce((acc, c) => acc + c.metrics.reactivationRate, 0) / (domainCampaigns.length || 1)
  ).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-indigo-400 font-semibold tracking-wide uppercase font-mono flex items-center gap-1.5">
            <RotateCcw className="w-3.5 h-3.5" />
            Automated Reactivation Pipeline
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Win-Back Campaign Sequences
          </h1>
          <p className="text-xs text-slate-300">
            Automated multi-touch outreach recovering cancelled subscribers with tailored value propositions and incentives.
          </p>
        </div>

        <button
          onClick={handleTestReactivation}
          className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 shrink-0"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Simulate Win-Back Test Send</span>
        </button>
      </div>

      {/* Aggregate Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">Reclaimed Revenue</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            ${totalReclaimed.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400">Total recovered ARR / MRR</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">Reactivation Rate</div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {avgReactivation}%
          </div>
          <div className="text-[11px] text-slate-400">Industry benchmark: 8–10%</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">Average Open Rate</div>
          <div className="text-2xl font-bold text-indigo-300 font-mono tabular-nums">
            51.4%
          </div>
          <div className="text-[11px] text-slate-400">High-deliverability domain routing</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">Active Sequences</div>
          <div className="text-2xl font-bold text-slate-200 font-mono tabular-nums">
            {domainCampaigns.length}
          </div>
          <div className="text-[11px] text-slate-400">30–60 day coverage</div>
        </div>
      </div>

      {testSentAlert && (
        <div className="p-4 bg-emerald-950/60 border border-emerald-500/40 rounded-xl flex items-center justify-between text-xs text-emerald-300 animate-in fade-in duration-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Win-Back dispatch simulated! Subscriber reactivated, adding <span className="font-bold text-white">${domain === 'dtc' ? '$48' : '$1,250'}</span> to reclaimed revenue.
            </span>
          </div>
          <span className="font-mono text-[10px] uppercase font-bold text-emerald-400">Reactivated</span>
        </div>
      )}

      {/* Main Campaign Builder Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Sequence Selector */}
        <div className="lg:col-span-4 space-y-3">
          <h2 className="text-sm font-semibold text-white tracking-tight">
            Outreach Cadence Sequence
          </h2>

          <div className="space-y-2">
            {domainCampaigns.map((camp) => {
              const isSelected = camp.id === selectedCampId;

              return (
                <div
                  key={camp.id}
                  onClick={() => setSelectedCampId(camp.id)}
                  className={`p-4 rounded-xl border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-850 border-indigo-500/80 shadow-md text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded bg-indigo-950/60 text-indigo-300 border border-indigo-500/30">
                        Day {camp.triggerDelayDays}
                      </span>
                      <span className="font-semibold text-slate-100">{camp.name}</span>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 mt-2 line-clamp-1">
                    "{camp.subjectLine}"
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>Reactivation: <span className="text-emerald-400 font-bold">{camp.metrics.reactivationRate}%</span></span>
                    <span>Reclaimed: <span className="text-white">${camp.metrics.reclaimedRevenue.toLocaleString()}</span></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Middle/Right Column: Campaign Editor & Live Email Preview */}
        <div className="lg:col-span-8 space-y-6">
          {activeCampaign ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Campaign Settings Editor */}
              <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 text-xs">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="font-semibold text-white">Campaign Template Editor</h3>
                  <button
                    onClick={handleSaveDraft}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{isSavedAlert ? 'Saved!' : 'Save Sequence'}</span>
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Email Subject Line</label>
                    <input
                      type="text"
                      value={subjectLine}
                      onChange={(e) => setSubjectLine(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Preheader Preview Text</label>
                    <input
                      type="text"
                      value={previewText}
                      onChange={(e) => setPreviewText(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Body Copy / Re-Engagement Narrative</label>
                    <textarea
                      rows={4}
                      value={bodySnippet}
                      onChange={(e) => setBodySnippet(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 resize-none leading-relaxed"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Reactivation Promo Code</label>
                      <input
                        type="text"
                        value={discountCode}
                        onChange={(e) => setDiscountCode(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 font-mono font-medium focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Trigger Cadence</label>
                      <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-400 font-mono">
                        Day +{activeCampaign.triggerDelayDays} Post-Churn
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Live Rendered Email Preview */}
              <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800">
                    <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-indigo-400" />
                      Rendered Email Preview
                    </span>
                    <span className="font-mono text-[10px]">Recipient: Elena Rostova</span>
                  </div>

                  {/* Simulated Mail Client Shell */}
                  <div className="mt-3 bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
                    <div className="space-y-1 pb-3 border-b border-slate-800/80">
                      <div className="text-[11px] text-slate-400">
                        From: <span className="text-slate-200 font-medium">{domain === 'dtc' ? 'Marcus at Verve Botanic <marcus@vervebotanic.com>' : 'Alex Rivera at HyperScale <alex@hyperscale.io>'}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Subject: <span className="text-white font-semibold">{subjectLine}</span>
                      </div>
                    </div>

                    <div className="space-y-3 pt-1 text-slate-300 leading-relaxed text-[11px]">
                      <p>Hi Elena,</p>
                      <p>{bodySnippet}</p>

                      {/* Offer Callout in Email */}
                      <div className="p-3 bg-indigo-950/40 border border-indigo-500/30 rounded-lg space-y-1">
                        <div className="text-[10px] font-mono text-indigo-300 uppercase font-bold">
                          Exclusive Reactivation Perk
                        </div>
                        <div className="text-white font-semibold">
                          {activeCampaign.incentiveText}
                        </div>
                        {discountCode && (
                          <div className="text-[10px] font-mono text-emerald-400 pt-0.5">
                            Promo code: <span className="font-bold underline">{discountCode}</span> (Auto-applied)
                          </div>
                        )}
                      </div>

                      <p>If you'd like to resume, you can reactivate with a single click below:</p>

                      <div className="pt-1">
                        <button
                          onClick={handleTestReactivation}
                          className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow transition-colors text-center text-xs"
                        >
                          1-Click Rejoin Subscription
                        </button>
                      </div>

                      <p className="text-[10px] text-slate-500 pt-2 text-center">
                        Your account preferences and previous history are safely preserved.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-slate-400 text-center">
                  Live email client rendering synchronized with template editor
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};
