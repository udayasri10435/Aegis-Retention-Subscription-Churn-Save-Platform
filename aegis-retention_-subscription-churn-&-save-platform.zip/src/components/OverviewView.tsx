import React from 'react';
import { 
  TrendingDown, 
  TrendingUp, 
  ShieldAlert, 
  DollarSign, 
  CheckCircle, 
  ArrowUpRight, 
  Users, 
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { DomainMode, RetentionMetrics, ChurnSignal, Subscriber } from '../types/retention';

interface OverviewViewProps {
  domain: DomainMode;
  metrics: RetentionMetrics;
  signals: ChurnSignal[];
  subscribers: Subscriber[];
  onSelectSubscriber: (sub: Subscriber) => void;
  onOpenCancelSimulator: () => void;
  onNavigateToTab: (tab: any) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  domain,
  metrics,
  signals,
  subscribers,
  onSelectSubscriber,
  onOpenCancelSimulator,
  onNavigateToTab
}) => {
  const atRiskList = subscribers.filter(s => s.domain === domain && (s.riskLevel === 'critical' || s.riskLevel === 'high'));

  // Calculate total MRR at risk
  const mrrAtRisk = atRiskList.reduce((acc, s) => acc + s.mrrEquivalent, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner / Callout */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-indigo-400 font-semibold tracking-wide flex items-center gap-1.5 uppercase font-mono">
            <span>{domain === 'dtc' ? 'Verve Botanic DTC' : 'HyperScale Cloud SaaS'}</span>
            <span aria-hidden="true">·</span>
            <span>Predictive Engine Running</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Retention & Churn Command Center
          </h1>
          <p className="text-xs text-slate-300">
            Real-time subscriber risk modeling, automated cancel deflection offers, and win-back pipeline.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigateToTab('predictive_churn')}
            className="px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-750 border border-slate-700/80 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <span>Review At-Risk Accounts</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onOpenCancelSimulator}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Launch Exit Simulator</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Active MRR / Base */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Active Subscription Base</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums tracking-tight">
            ${(metrics.mrr).toLocaleString()}
            <span className="text-xs text-slate-400 font-sans ml-1 font-normal">
              {domain === 'dtc' ? 'MRR' : 'MRR ($6.8M ARR)'}
            </span>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <span className="font-mono text-emerald-400 font-medium">+5.4% YoY</span>
            <span>·</span>
            <span>{metrics.totalSubscribers.toLocaleString()} subscribers</span>
          </div>
        </div>

        {/* Card 2: Churn Rate */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Gross Churn Rate</span>
            <span className="text-xs font-mono font-medium px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
              Net: {metrics.netChurnRate > 0 ? `+${metrics.netChurnRate}%` : `${metrics.netChurnRate}%`}
            </span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums tracking-tight">
            {metrics.grossChurnRate}%
            <span className="text-xs text-slate-400 font-sans ml-1 font-normal">/ month</span>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <span className="font-mono text-emerald-400 font-medium">-0.4% vs benchmark</span>
            <span>·</span>
            <span>Target: &lt; {domain === 'dtc' ? '5.0%' : '2.0%'}</span>
          </div>
        </div>

        {/* Card 3: Saved Revenue */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Saved via Exit Offers</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums tracking-tight">
            ${(metrics.savedRevenueThisMonth).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <span className="font-mono text-emerald-400 font-medium">{metrics.saveOfferAcceptanceRate}% accept rate</span>
            <span>·</span>
            <span>This billing cycle</span>
          </div>
        </div>

        {/* Card 4: Win-Back Revenue */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Reclaimed via Win-Back</span>
            <RotateCcw className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-indigo-300 font-mono tabular-nums tracking-tight">
            ${(metrics.reclaimedRevenueThisMonth).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <span className="font-mono text-indigo-400 font-medium">{metrics.winBackReactivationRate}% win-back</span>
            <span>·</span>
            <span>Automated sequences</span>
          </div>
        </div>
      </div>

      {/* Middle Section: Predictive Hazard Curve + Risk Bands */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Predictive Churn Hazard Curve */}
        <div className="lg:col-span-2 p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white tracking-tight">
                Predictive Churn Hazard & Survival Probability
              </h2>
              <p className="text-xs text-slate-400">
                Machine learning projected attrition curve over 90 days if no save offers are triggered.
              </p>
            </div>
            <div className="text-xs text-slate-400 font-mono">
              Model AUC: <span className="text-emerald-400 font-bold">0.914</span>
            </div>
          </div>

          {/* SVG Hazard Curve Visualization */}
          <div className="h-56 w-full pt-4 relative select-none">
            <svg viewBox="0 0 600 180" className="w-full h-full overflow-visible">
              <defs>
                <linearGradient id="curveGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="savedCurveGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              <line x1="40" y1="20" x2="580" y2="20" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="40" y1="60" x2="580" y2="60" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="40" y1="100" x2="580" y2="100" stroke="#1e293b" strokeDasharray="3 3" />
              <line x1="40" y1="140" x2="580" y2="140" stroke="#1e293b" strokeDasharray="3 3" />

              {/* Y Axis Labels */}
              <text x="32" y="24" textAnchor="end" fill="#64748b" fontSize="10" className="font-mono">100%</text>
              <text x="32" y="64" textAnchor="end" fill="#64748b" fontSize="10" className="font-mono">75%</text>
              <text x="32" y="104" textAnchor="end" fill="#64748b" fontSize="10" className="font-mono">50%</text>
              <text x="32" y="144" textAnchor="end" fill="#64748b" fontSize="10" className="font-mono">25%</text>

              {/* Baseline Natural Decay Curve (No Save Flow) */}
              <path
                d="M 50,20 C 120,35 180,75 250,95 C 340,120 440,135 560,145"
                fill="none"
                stroke="#f43f5e"
                strokeWidth="2.5"
                strokeDasharray="4 4"
              />

              {/* Aegis Deflection Model Curve (With Save Offers & Win-Back) */}
              <path
                d="M 50,20 C 120,24 180,36 250,42 C 340,50 440,58 560,64 L 560,150 L 50,150 Z"
                fill="url(#savedCurveGradient)"
              />
              <path
                d="M 50,20 C 120,24 180,36 250,42 C 340,50 440,58 560,64"
                fill="none"
                stroke="#10b981"
                strokeWidth="3"
              />

              {/* Key Intervention Marker: Day 30 */}
              <line x1="250" y1="20" x2="250" y2="150" stroke="#6366f1" strokeWidth="1.5" strokeDasharray="2 2" />
              <circle cx="250" cy="42" r="5" fill="#6366f1" stroke="#ffffff" strokeWidth="2" />
              <text x="250" y="165" textAnchor="middle" fill="#818cf8" fontSize="10" className="font-mono font-bold">Day 30 (Critical Save Window)</text>

              {/* X Axis Labels */}
              <text x="50" y="165" textAnchor="middle" fill="#64748b" fontSize="10" className="font-mono">Day 0</text>
              <text x="400" y="165" textAnchor="middle" fill="#64748b" fontSize="10" className="font-mono">Day 60</text>
              <text x="560" y="165" textAnchor="middle" fill="#64748b" fontSize="10" className="font-mono">Day 90</text>
            </svg>
          </div>

          {/* Curve Legend */}
          <div className="pt-2 flex flex-wrap items-center justify-between border-t border-slate-800 text-xs text-slate-400">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="w-3 h-0.5 bg-emerald-400 rounded-full"></span>
                <span>With Aegis Save Offers (82% 90-Day Retention)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-0.5 bg-rose-500 rounded-full border-b border-dashed"></span>
                <span>Unmitigated Churn Baseline (54%)</span>
              </div>
            </div>
            <span className="text-emerald-400 font-mono font-medium">+28% Net Lift in LTV</span>
          </div>
        </div>

        {/* Risk Distribution Breakdown */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-tight">
              Customer Base Health Tiers
            </h2>
            <p className="text-xs text-slate-400">
              Risk distribution based on multi-signal hazard scoring.
            </p>
          </div>

          <div className="space-y-3">
            {/* Critical */}
            <div className="p-3 bg-rose-950/20 border border-rose-500/20 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-rose-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                  Critical Risk (&gt;80%)
                </span>
                <span className="font-mono font-bold text-white tabular-nums">
                  {metrics.riskDistribution.critical} accounts
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-rose-500 h-full rounded-full" 
                  style={{ width: `${(metrics.riskDistribution.critical / metrics.totalSubscribers) * 100 * 5}%` }}
                />
              </div>
              <div className="text-[11px] text-rose-300/80 flex justify-between">
                <span>Immediate save offer required</span>
                <span className="font-mono font-medium">${domain === 'dtc' ? '$24.6k' : '$142k'} at stake</span>
              </div>
            </div>

            {/* High */}
            <div className="p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  High Risk (60-79%)
                </span>
                <span className="font-mono font-bold text-white tabular-nums">
                  {metrics.riskDistribution.high} accounts
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-amber-500 h-full rounded-full" 
                  style={{ width: `${(metrics.riskDistribution.high / metrics.totalSubscribers) * 100 * 3}%` }}
                />
              </div>
              <div className="text-[11px] text-amber-300/80 flex justify-between">
                <span>Leading signals active</span>
                <span className="font-mono font-medium">${domain === 'dtc' ? '$48.1k' : '$198k'} at stake</span>
              </div>
            </div>

            {/* Moderate */}
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                  Moderate Risk (40-59%)
                </span>
                <span className="font-mono font-bold text-white tabular-nums">
                  {metrics.riskDistribution.moderate} accounts
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-yellow-500 h-full rounded-full" 
                  style={{ width: `${(metrics.riskDistribution.moderate / metrics.totalSubscribers) * 100}%` }}
                />
              </div>
            </div>

            {/* Healthy */}
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-emerald-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  Healthy (&lt;40%)
                </span>
                <span className="font-mono font-bold text-white tabular-nums">
                  {metrics.riskDistribution.healthy} accounts
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full" 
                  style={{ width: `${(metrics.riskDistribution.healthy / metrics.totalSubscribers) * 100}%` }}
                />
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateToTab('predictive_churn')}
            className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors flex items-center justify-center gap-1.5"
          >
            <span>Open Customer Risk Ledger</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Bottom Section: Top Signals + At-Risk Subscribers Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Churn Leading Signals */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white tracking-tight">
                Predictive Risk Factor Attribution
              </h2>
              <p className="text-xs text-slate-400">
                Primary leading indicators driving subscriber churn in {domain === 'dtc' ? 'DTC' : 'SaaS'}.
              </p>
            </div>
            <span className="text-[11px] font-mono text-indigo-400">Top 5 Features</span>
          </div>

          <div className="space-y-3">
            {signals.map((sig) => (
              <div
                key={sig.id}
                className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">{sig.name}</span>
                  <span className="font-mono font-bold text-indigo-400 tabular-nums">
                    {sig.weight}% Model Weight
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {sig.description}
                </p>
                <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                  <div 
                    className="bg-indigo-500 h-full rounded-full" 
                    style={{ width: `${sig.weight * 2}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Priority Intervention Queue */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-white tracking-tight">
                  High-Priority Intervention Queue
                </h2>
                <p className="text-xs text-slate-400">
                  Subscribers with upcoming renewals and critical churn risk.
                </p>
              </div>
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 rounded border border-rose-500/30">
                {atRiskList.length} Immediate Attention
              </span>
            </div>

            <div className="space-y-2.5 mt-4">
              {atRiskList.slice(0, 4).map((sub) => (
                <div
                  key={sub.id}
                  onClick={() => onSelectSubscriber(sub)}
                  className="p-3.5 bg-slate-950/70 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-xl transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-xs text-white group-hover:text-indigo-300 transition-colors">
                        {sub.name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {sub.planOrSku}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                      <span className="text-rose-400 font-medium">{sub.primaryRiskReason}</span>
                      <span>·</span>
                      <span>Renewal: {sub.nextBillingDate}</span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono text-xs font-bold text-rose-400 tabular-nums">
                      {sub.riskScore}% Risk
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      ${sub.mrrEquivalent}/mo MRR
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">
              Total MRR in this queue: <span className="font-mono font-bold text-white">${mrrAtRisk.toLocaleString()}</span>
            </span>
            <button
              onClick={() => onNavigateToTab('predictive_churn')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
            >
              <span>View Full Risk Ledger</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
