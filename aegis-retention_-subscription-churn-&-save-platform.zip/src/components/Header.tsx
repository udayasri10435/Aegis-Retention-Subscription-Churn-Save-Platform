import React from 'react';
import { DomainMode } from '../types/retention';
import { Play, Sparkles, RefreshCw } from 'lucide-react';

interface HeaderProps {
  currentDomain: DomainMode;
  onDomainChange: (domain: DomainMode) => void;
  onOpenCancelSimulator: () => void;
  onResetData: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentDomain,
  onDomainChange,
  onOpenCancelSimulator,
  onResetData
}) => {
  return (
    <header className="h-16 px-6 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 flex items-center justify-between z-30 shrink-0">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-6">
        <a href="/" className="text-lg font-bold tracking-tight text-white flex items-center gap-2.5">
          <span className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-sm font-bold text-sm">
            AE
          </span>
          <span className="text-slate-100 font-semibold tracking-tight">Aegis Retention</span>
        </a>

        {/* Domain Mode Switcher - Segmented Control for DTC vs SaaS */}
        <div className="hidden sm:flex items-center p-1 bg-slate-950/80 rounded-lg border border-slate-800/80 text-xs">
          <button
            onClick={() => onDomainChange('dtc')}
            className={`px-3 py-1.5 font-medium rounded-md transition-all duration-150 whitespace-nowrap ${
              currentDomain === 'dtc'
                ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            DTC Brand: Verve Botanic
          </button>
          <button
            onClick={() => onDomainChange('saas')}
            className={`px-3 py-1.5 font-medium rounded-md transition-all duration-150 whitespace-nowrap ${
              currentDomain === 'saas'
                ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            B2B SaaS: HyperScale Cloud
          </button>
        </div>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden xl:flex items-center gap-6 text-xs font-medium text-slate-400">
        <span className="text-slate-300 font-semibold">Active Model: Hazard-ML v2.8</span>
        <span aria-hidden="true">·</span>
        <span>Target Renewal Window: 30 Days</span>
        <span aria-hidden="true">·</span>
        <span className="text-emerald-400 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          Live Ingestion Active
        </span>
      </nav>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={onResetData}
          title="Reset simulated retention metrics"
          className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors border border-transparent hover:border-slate-700"
        >
          <RefreshCw className="w-4 h-4" />
        </button>

        <button
          onClick={onOpenCancelSimulator}
          className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-lg shadow-sm transition-all whitespace-nowrap"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Simulate Cancellation Flow</span>
        </button>
      </div>
    </header>
  );
};
