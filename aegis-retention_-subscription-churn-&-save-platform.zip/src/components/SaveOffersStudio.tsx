import React, { useState } from 'react';
import { 
  Gift, 
  Percent, 
  PauseCircle, 
  Plus, 
  Play, 
  ArrowRight, 
  CheckCircle, 
  DollarSign, 
  TrendingUp, 
  ToggleLeft, 
  ToggleRight,
  Sparkles,
  HelpCircle,
  ShieldCheck
} from 'lucide-react';
import { DomainMode, SaveOffer } from '../types/retention';
import { NewOfferModal } from './NewOfferModal';

interface SaveOffersStudioProps {
  domain: DomainMode;
  offers: SaveOffer[];
  onOpenCancelSimulator: () => void;
  onToggleOfferStatus: (offerId: string) => void;
  onAddOffer: (newOffer: Partial<SaveOffer>) => void;
}

export const SaveOffersStudio: React.FC<SaveOffersStudioProps> = ({
  domain,
  offers,
  onOpenCancelSimulator,
  onToggleOfferStatus,
  onAddOffer
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const domainOffers = offers.filter(o => o.domain === domain);
  const totalSavedRevenue = domainOffers.reduce((acc, o) => acc + o.savedRevenue, 0);
  const totalAcceptedCount = domainOffers.reduce((acc, o) => acc + o.timesAccepted, 0);

  return (
    <div className="space-y-6">
      {/* Header and Hero Actions */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs text-indigo-400 font-semibold tracking-wide uppercase font-mono flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Dynamic Exit Survey & Save Offers
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Cancellation Flow & Save Studio
          </h1>
          <p className="text-xs text-slate-300">
            Targeted economic incentives, delivery pauses, and tier downgrade offers triggered dynamically upon cancellation intent.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-3.5 py-2 text-xs font-medium text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Save Offer</span>
          </button>
          <button
            onClick={onOpenCancelSimulator}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Test Cancellation Flow</span>
          </button>
        </div>
      </div>

      {/* Aggregate Save Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">Net Saved Recurring Revenue</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            ${totalSavedRevenue.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400">Preserved from voluntary churn</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">Total Saved Subscribers</div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {totalAcceptedCount.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400">Accepted save offer during exit survey</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">Average Deflection Rate</div>
          <div className="text-2xl font-bold text-indigo-400 font-mono tabular-nums">
            {domain === 'dtc' ? '38.4%' : '33.5%'}
          </div>
          <div className="text-[11px] text-slate-400">+12.1% above industry standard</div>
        </div>
      </div>

      {/* Save Offers Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white tracking-tight">
            Active Deflection Offers ({domainOffers.length})
          </h2>
          <span className="text-xs text-slate-400">
            Rules mapped to exit survey sentiment
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {domainOffers.map((offer) => {
            const isActive = offer.status === 'active';

            return (
              <div
                key={offer.id}
                className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 relative overflow-hidden flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-slate-800 text-indigo-400 rounded-xl border border-slate-700 shrink-0">
                        {offer.offerType === 'pause' ? <PauseCircle className="w-5 h-5" /> :
                         offer.offerType === 'discount' ? <Percent className="w-5 h-5" /> :
                         offer.offerType === 'gift' ? <Gift className="w-5 h-5" /> :
                         <ShieldCheck className="w-5 h-5" />}
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-white">{offer.title}</h3>
                        <div className="text-[11px] text-slate-400 capitalize mt-0.5">
                          Type: <span className="text-slate-300 font-medium">{offer.offerType.replace('_', ' ')}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => onToggleOfferStatus(offer.id)}
                      className="text-slate-400 hover:text-white transition-colors"
                      title={isActive ? 'Pause offer' : 'Activate offer'}
                    >
                      {isActive ? (
                        <ToggleRight className="w-7 h-7 text-emerald-400" />
                      ) : (
                        <ToggleLeft className="w-7 h-7 text-slate-600" />
                      )}
                    </button>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {offer.description}
                  </p>

                  <div className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-lg text-xs space-y-1">
                    <div className="text-[10px] font-mono uppercase text-indigo-400 font-semibold">
                      Incentive Payload:
                    </div>
                    <div className="font-medium text-slate-200">{offer.incentiveValue}</div>
                  </div>

                  {/* Targeted Exit Reasons */}
                  <div className="space-y-1.5">
                    <div className="text-[11px] font-medium text-slate-400">Triggered on Exit Reasons:</div>
                    <div className="flex flex-wrap gap-1.5">
                      {offer.targetReason.map((reason, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 text-[10px] bg-slate-950 text-slate-300 border border-slate-800 rounded font-medium"
                        >
                          {reason}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Offer Performance Stats */}
                <div className="pt-3 border-t border-slate-800 grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 bg-slate-950/40 rounded-lg">
                    <div className="text-[10px] text-slate-400">Acceptance</div>
                    <div className="font-mono font-bold text-emerald-400 mt-0.5 tabular-nums">
                      {offer.acceptanceRate}%
                    </div>
                  </div>
                  <div className="p-2 bg-slate-950/40 rounded-lg">
                    <div className="text-[10px] text-slate-400">Times Saved</div>
                    <div className="font-mono font-bold text-white mt-0.5 tabular-nums">
                      {offer.timesAccepted}
                    </div>
                  </div>
                  <div className="p-2 bg-slate-950/40 rounded-lg">
                    <div className="text-[10px] text-slate-400">Saved Revenue</div>
                    <div className="font-mono font-bold text-indigo-300 mt-0.5 tabular-nums">
                      ${offer.savedRevenue.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rules Engine Flow Architecture Diagram */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
        <h2 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
          <span>Dynamic Rules & Arbitration Pipeline</span>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-1.5 py-0.5 rounded">
            Active
          </span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Step 1: Signal Ingestion</div>
            <div className="font-semibold text-white">Subscriber Initiates Exit</div>
            <div className="text-slate-400 text-[11px] leading-relaxed">
              Clicks cancel button in customer portal or billing panel.
            </div>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Step 2: Exit Reason Survey</div>
            <div className="font-semibold text-white">Sentiment Classification</div>
            <div className="text-slate-400 text-[11px] leading-relaxed">
              Classified into: Price, Backlog/Usage, Quality, or Temporary.
            </div>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1">
            <div className="text-[10px] font-mono text-indigo-400 uppercase">Step 3: Offer Arbitration</div>
            <div className="font-semibold text-white">Dynamic Save Matching</div>
            <div className="text-slate-400 text-[11px] leading-relaxed">
              Evaluates subscriber LTV & tenure to select highest-converting offer.
            </div>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1">
            <div className="text-[10px] font-mono text-emerald-400 uppercase">Step 4: Real-time Resolution</div>
            <div className="font-semibold text-white">Instant Save or Win-Back</div>
            <div className="text-slate-400 text-[11px] leading-relaxed">
              1-click discount/pause applied, or automatically enrolled in Win-Back.
            </div>
          </div>
        </div>
      </div>

      <NewOfferModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        domain={domain}
        onSaveOffer={onAddOffer}
      />
    </div>
  );
};
