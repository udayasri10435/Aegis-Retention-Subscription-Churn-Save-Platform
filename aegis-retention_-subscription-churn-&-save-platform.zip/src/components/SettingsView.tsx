import React, { useState } from 'react';
import { 
  Sliders, 
  CheckCircle, 
  RefreshCw, 
  Zap, 
  ShieldCheck, 
  ExternalLink,
  Layers,
  AlertTriangle
} from 'lucide-react';
import { DomainMode } from '../types/retention';

interface SettingsViewProps {
  domain: DomainMode;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ domain }) => {
  const [maxDiscountCap, setMaxDiscountCap] = useState(40);
  const [riskAlertThreshold, setRiskAlertThreshold] = useState(75);
  const [maxPauseCycles, setMaxPauseCycles] = useState(2);
  const [webhookTested, setWebhookTested] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleTestWebhook = () => {
    setWebhookTested(true);
    setTimeout(() => setWebhookTested(false), 3000);
  };

  const handleSaveSettings = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight">
          Retention Engine Settings & Integrations
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure financial guardrails, automated risk alert thresholds, and billing sync gateways.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Retention Guardrails Form */}
        <div className="lg:col-span-7 p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-6 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-sm font-semibold text-white tracking-tight">
              Economic Guardrails & Thresholds
            </h2>
            <button
              onClick={handleSaveSettings}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg transition-colors"
            >
              {isSaved ? 'Settings Saved!' : 'Save Changes'}
            </button>
          </div>

          {/* Slider 1: Risk Alert Threshold */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 font-medium">Predictive Risk Alert Threshold</label>
              <span className="font-mono font-bold text-indigo-400 text-sm">{riskAlertThreshold}%</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Subscribers scoring equal or above this probability are automatically flagged into the Critical Intervention Queue.
            </p>
            <input
              type="range"
              min="50"
              max="95"
              step="5"
              value={riskAlertThreshold}
              onChange={(e) => setRiskAlertThreshold(Number(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          {/* Slider 2: Max Discount Allowance */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 font-medium">Maximum Save Offer Discount Allowance</label>
              <span className="font-mono font-bold text-emerald-400 text-sm">{maxDiscountCap}%</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Hard economic boundary preventing automated save flows from offering concessions higher than gross margin limits.
            </p>
            <input
              type="range"
              min="10"
              max="60"
              step="5"
              value={maxDiscountCap}
              onChange={(e) => setMaxDiscountCap(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Setting 3: Max Pause Allowance */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 font-medium">Maximum Consecutive Pause Cycles</label>
              <span className="font-mono font-bold text-slate-200 text-sm">{maxPauseCycles} cycles</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Limits how many consecutive subscription renewals a customer can snooze before requiring reactivation or consultation.
            </p>
            <div className="flex gap-2">
              {[1, 2, 3, 4].map((cycles) => (
                <button
                  key={cycles}
                  type="button"
                  onClick={() => setMaxPauseCycles(cycles)}
                  className={`px-3 py-1.5 rounded-lg font-mono font-medium border text-xs ${
                    maxPauseCycles === cycles
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {cycles} {cycles === 1 ? 'Cycle' : 'Cycles'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Active Integrations */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-sm font-semibold text-white tracking-tight">
                Billing & Lifecycle Gateways
              </h2>
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                Healthy
              </span>
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white">Stripe Billing API</div>
                  <div className="text-[11px] text-slate-400">Real-time webhook listener & dunning</div>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 rounded">
                  Connected
                </span>
              </div>

              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white">
                    {domain === 'dtc' ? 'Shopify / Recharge Engine' : 'Salesforce / HubSpot CRM'}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {domain === 'dtc' ? 'Order skips, frequency & SKU changes' : 'Contract sync & account telemetry'}
                  </div>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 rounded">
                  Connected
                </span>
              </div>

              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white">Klaviyo & Postmark Dispatch</div>
                  <div className="text-[11px] text-slate-400">Win-back email deliverability cluster</div>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 rounded">
                  Connected
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <button
                onClick={handleTestWebhook}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 font-medium rounded-lg border border-slate-700 transition-colors flex items-center justify-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Simulate Stripe Webhook Event</span>
              </button>

              {webhookTested && (
                <div className="mt-2 p-2 bg-emerald-950/40 border border-emerald-500/30 rounded-lg text-emerald-300 text-[11px] text-center">
                  Webhook payload delivered & processed in 18ms.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
