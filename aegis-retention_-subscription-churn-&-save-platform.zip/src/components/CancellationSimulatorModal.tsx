import React, { useState } from 'react';
import { 
  X, 
  CheckCircle, 
  AlertTriangle, 
  ArrowRight, 
  Gift, 
  PauseCircle, 
  Percent, 
  ShieldCheck, 
  RotateCcw,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { DomainMode, Subscriber, SaveOffer } from '../types/retention';
import { DTC_CHURN_REASONS, SAAS_CHURN_REASONS, DTC_SAVE_OFFERS, SAAS_SAVE_OFFERS } from '../data/mockData';

interface CancellationSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  domain: DomainMode;
  subscribers: Subscriber[];
  onSubscriberSaved: (subscriberId: string, offer: SaveOffer) => void;
  onSubscriberCancelled: (subscriberId: string, reason: string) => void;
}

export const CancellationSimulatorModal: React.FC<CancellationSimulatorModalProps> = ({
  isOpen,
  onClose,
  domain,
  subscribers,
  onSubscriberSaved,
  onSubscriberCancelled
}) => {
  if (!isOpen) return null;

  const candidateSubscribers = subscribers.filter(s => s.domain === domain);
  const [selectedSubId, setSelectedSubId] = useState<string>(candidateSubscribers[0]?.id || '');
  const activeSubscriber = candidateSubscribers.find(s => s.id === selectedSubId) || candidateSubscribers[0];

  const reasons = domain === 'dtc' ? DTC_CHURN_REASONS : SAAS_CHURN_REASONS;
  const offers = domain === 'dtc' ? DTC_SAVE_OFFERS : SAAS_SAVE_OFFERS;

  const [step, setStep] = useState<'reason' | 'offer' | 'outcome_saved' | 'outcome_cancelled'>('reason');
  const [selectedReason, setSelectedReason] = useState<string>(reasons[0].reason);
  const [matchedOffer, setMatchedOffer] = useState<SaveOffer>(offers[0]);

  const handleSelectReasonAndProceed = () => {
    // Intelligent offer routing logic based on selected reason
    let chosenOffer = offers[0];
    if (selectedReason.toLowerCase().includes('too much') || selectedReason.toLowerCase().includes('under-utilized')) {
      chosenOffer = offers.find(o => o.offerType === 'pause' || o.offerType === 'downgrade') || offers[0];
    } else if (selectedReason.toLowerCase().includes('expensive') || selectedReason.toLowerCase().includes('budget')) {
      chosenOffer = offers.find(o => o.offerType === 'discount') || offers[0];
    } else if (selectedReason.toLowerCase().includes('feature') || selectedReason.toLowerCase().includes('damaged') || selectedReason.toLowerCase().includes('quality')) {
      chosenOffer = offers.find(o => o.offerType === 'concierge' || o.offerType === 'gift') || offers[0];
    } else {
      chosenOffer = offers[1] || offers[0];
    }

    setMatchedOffer(chosenOffer);
    setStep('offer');
  };

  const handleAcceptOffer = () => {
    if (activeSubscriber) {
      onSubscriberSaved(activeSubscriber.id, matchedOffer);
    }
    setStep('outcome_saved');
  };

  const handleDeclineOffer = () => {
    if (activeSubscriber) {
      onSubscriberCancelled(activeSubscriber.id, selectedReason);
    }
    setStep('outcome_cancelled');
  };

  const handleRestart = () => {
    setStep('reason');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-ping"></span>
            <div>
              <h2 className="text-sm font-semibold text-white tracking-tight">
                Live Cancellation Flow Simulator
              </h2>
              <p className="text-xs text-slate-400">
                Simulating {domain === 'dtc' ? 'Verve Botanic Customer Portal' : 'HyperScale Cloud Workspace Settings'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Simulator Target Subscriber Selector */}
        <div className="px-6 py-3 bg-slate-950/30 border-b border-slate-800/80 flex items-center justify-between gap-4 text-xs">
          <div className="text-slate-400 flex items-center gap-1.5">
            <span>Simulating Subscriber:</span>
            <select
              value={selectedSubId}
              onChange={(e) => {
                setSelectedSubId(e.target.value);
                setStep('reason');
              }}
              className="bg-slate-800 text-slate-200 border border-slate-700 rounded-md px-2 py-1 font-medium focus:outline-none focus:border-indigo-500"
            >
              {candidateSubscribers.map(sub => (
                <option key={sub.id} value={sub.id}>
                  {sub.name} ({sub.planOrSku} · ${sub.value}{domain === 'dtc' ? '/shipment' : '/mo'})
                </option>
              ))}
            </select>
          </div>

          <div className="text-right">
            <span className="text-slate-400">Current Health: </span>
            <span className={`font-mono font-semibold ${
              activeSubscriber.riskLevel === 'critical' ? 'text-rose-400' :
              activeSubscriber.riskLevel === 'high' ? 'text-amber-400' :
              activeSubscriber.riskLevel === 'moderate' ? 'text-yellow-400' : 'text-emerald-400'
            }`}>
              {activeSubscriber.riskScore}% Churn Risk
            </span>
          </div>
        </div>

        {/* Step Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {step === 'reason' && (
            <div className="space-y-5">
              <div className="text-center max-w-md mx-auto space-y-1.5">
                <div className="inline-flex p-3 rounded-full bg-slate-800 text-slate-300 mb-1">
                  <HelpCircle className="w-6 h-6 text-indigo-400" />
                </div>
                <h3 className="text-base font-semibold text-white">
                  We're sorry to see you go, {activeSubscriber.name.split(' ')[0]}
                </h3>
                <p className="text-xs text-slate-400">
                  Please let us know why you are cancelling your {activeSubscriber.planOrSku} subscription so we can improve.
                </p>
              </div>

              <div className="space-y-2 mt-4">
                {reasons.map((r, idx) => (
                  <label
                    key={idx}
                    onClick={() => setSelectedReason(r.reason)}
                    className={`flex items-start gap-3 p-3.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      selectedReason === r.reason
                        ? 'bg-indigo-950/40 border-indigo-500/80 text-white shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-850'
                    }`}
                  >
                    <input
                      type="radio"
                      name="cancel_reason"
                      checked={selectedReason === r.reason}
                      onChange={() => setSelectedReason(r.reason)}
                      className="mt-0.5 text-indigo-600 focus:ring-0 focus:outline-none"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-slate-200">{r.reason}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Historical frequency: {r.percent}% of cancellations
                      </div>
                    </div>
                  </label>
                ))}
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
                >
                  Never mind, keep subscription
                </button>
                <button
                  onClick={handleSelectReasonAndProceed}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <span>Continue</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {step === 'offer' && (
            <div className="space-y-6">
              <div className="p-4 bg-indigo-950/30 border border-indigo-500/30 rounded-xl space-y-1">
                <div className="text-[11px] font-mono uppercase text-indigo-400 font-semibold tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  AI-Engineered Save Offer Matched
                </div>
                <div className="text-xs text-slate-300">
                  Targeted specifically for: <span className="text-white font-medium">"{selectedReason}"</span>
                </div>
              </div>

              {/* Offer Card */}
              <div className="p-6 bg-slate-950/80 border border-slate-700/80 rounded-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-600/10 rounded-full blur-2xl pointer-events-none"></div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-indigo-600/20 text-indigo-400 rounded-xl shrink-0 border border-indigo-500/30">
                    {matchedOffer.offerType === 'pause' ? <PauseCircle className="w-7 h-7" /> :
                     matchedOffer.offerType === 'discount' ? <Percent className="w-7 h-7" /> :
                     <Gift className="w-7 h-7" />}
                  </div>

                  <div className="space-y-2 flex-1">
                    <h4 className="text-base font-bold text-white tracking-tight">
                      {matchedOffer.title}
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {matchedOffer.description}
                    </p>

                    <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 text-xs font-mono text-emerald-400 flex items-center justify-between">
                      <span className="text-slate-400 font-sans">Applied Incentive:</span>
                      <span className="font-semibold">{matchedOffer.incentiveValue}</span>
                    </div>

                    <div className="text-[11px] text-slate-400 pt-1">
                      Historical Save Rate for this offer: <span className="font-mono text-slate-300 font-medium">{matchedOffer.acceptanceRate}%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Subscriber Choice Actions */}
              <div className="pt-2 space-y-3">
                <button
                  onClick={handleAcceptOffer}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Accept Offer & Keep Subscription</span>
                </button>

                <button
                  onClick={handleDeclineOffer}
                  className="w-full py-2.5 px-4 bg-transparent hover:bg-rose-500/10 text-rose-400 hover:text-rose-300 text-xs font-medium rounded-xl border border-rose-500/20 transition-all flex items-center justify-center gap-1.5"
                >
                  <span>No thanks, proceed with cancellation</span>
                </button>
              </div>
            </div>
          )}

          {step === 'outcome_saved' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">Subscriber Successfully Saved!</h3>
                <p className="text-xs text-slate-300 max-w-md mx-auto">
                  {activeSubscriber.name} accepted <span className="text-emerald-400 font-medium">{matchedOffer.title}</span>.
                  The discount/pause was applied immediately to their billing schedule.
                </p>
              </div>

              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl max-w-sm mx-auto text-xs space-y-2">
                <div className="flex justify-between text-slate-400">
                  <span>Preserved Value:</span>
                  <span className="font-mono text-white font-semibold">
                    ${activeSubscriber.value} {domain === 'dtc' ? '/cycle' : '/mo'}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>New Churn Risk:</span>
                  <span className="font-mono text-emerald-400 font-semibold">
                    Deflected to 18% (Healthy)
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Status:</span>
                  <span className="font-mono text-emerald-400 font-semibold">
                    Active (Saved)
                  </span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-center gap-3">
                <button
                  onClick={handleRestart}
                  className="px-4 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Test Another Flow</span>
                </button>
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg"
                >
                  Done
                </button>
              </div>
            </div>
          )}

          {step === 'outcome_cancelled' && (
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-full flex items-center justify-center mx-auto">
                <AlertTriangle className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">Subscription Cancelled</h3>
                <p className="text-xs text-slate-300 max-w-md mx-auto">
                  {activeSubscriber.name} declined the offer and finalized cancellation.
                  Reason recorded: <span className="text-rose-400 font-medium">"{selectedReason}"</span>.
                </p>
              </div>

              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl max-w-sm mx-auto text-xs space-y-2 text-left">
                <div className="text-[11px] font-semibold text-indigo-400 uppercase tracking-wide">
                  Automated Next Steps Triggered:
                </div>
                <div className="flex items-center gap-2 text-slate-300 text-[11px]">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Logged in Churn Pareto analytics</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300 text-[11px]">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Enrolled in Day 3 Post-Cancellation Win-Back sequence</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300 text-[11px]">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Customer feedback survey dispatched</span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-center gap-3">
                <button
                  onClick={handleRestart}
                  className="px-4 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Test Another Flow</span>
                </button>
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg"
                >
                  Close Simulator
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
