export type DomainMode = 'dtc' | 'saas';

export type RiskLevel = 'critical' | 'high' | 'moderate' | 'healthy';

export interface ChurnSignal {
  id: string;
  name: string;
  weight: number; // 0 - 100%
  description: string;
  category: 'behavior' | 'billing' | 'support' | 'product';
  changePercent?: number;
}

export interface Subscriber {
  id: string;
  name: string;
  email: string;
  companyOrHandle?: string;
  avatarUrl?: string;
  domain: DomainMode;
  planOrSku: string;
  cadence: 'monthly' | 'quarterly' | 'annual' | 'bi-weekly';
  value: number; // MRR for SaaS or Order Value for DTC
  mrrEquivalent: number;
  tenureMonths: number;
  riskScore: number; // 0 - 100
  riskLevel: RiskLevel;
  primaryRiskReason: string;
  signals: {
    name: string;
    severity: 'high' | 'medium' | 'low';
    detectedAt: string;
  }[];
  nextBillingDate: string;
  status: 'active' | 'at_risk' | 'saved' | 'churned';
  lastIntervention?: {
    type: string;
    date: string;
    outcome: string;
  };
}

export interface SaveOffer {
  id: string;
  domain: DomainMode;
  title: string;
  offerType: 'discount' | 'pause' | 'cadence_swap' | 'gift' | 'concierge' | 'downgrade';
  description: string;
  incentiveValue: string; // e.g. "30% off for 2 cycles", "60-day pause"
  targetReason: string[];
  minimumTenureMonths?: number;
  minimumValue?: number;
  acceptanceRate: number; // percentage e.g. 38.5%
  timesOffered: number;
  timesAccepted: number;
  savedRevenue: number;
  marginCostEstimate: number;
  status: 'active' | 'paused';
}

export interface WinBackCampaign {
  id: string;
  domain: DomainMode;
  name: string;
  triggerDelayDays: number;
  status: 'active' | 'paused' | 'draft';
  subjectLine: string;
  previewText: string;
  bodySnippet: string;
  incentiveText: string;
  discountCode?: string;
  metrics: {
    targetedSubscribers: number;
    sentCount: number;
    openRate: number;
    clickRate: number;
    reactivationRate: number;
    reclaimedRevenue: number;
  };
  steps: {
    id: string;
    dayOffset: number;
    channel: 'email' | 'sms' | 'in_app';
    title: string;
    hook: string;
  }[];
}

export interface CohortRow {
  cohortMonth: string;
  startingSubscribers: number;
  startingMrr: number;
  retentionByMonth: number[]; // percentage retention at M0, M1, M2... M11
}

export interface RetentionMetrics {
  totalSubscribers: number;
  mrr: number;
  grossChurnRate: number; // %
  netChurnRate: number; // %
  saveOfferAcceptanceRate: number; // %
  savedRevenueThisMonth: number;
  winBackReactivationRate: number; // %
  reclaimedRevenueThisMonth: number;
  riskDistribution: {
    critical: number;
    high: number;
    moderate: number;
    healthy: number;
  };
}
